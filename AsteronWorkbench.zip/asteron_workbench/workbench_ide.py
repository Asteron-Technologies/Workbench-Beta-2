#!/usr/bin/env python3
"""
Asteron Workbench — IDE & Circuit Simulator v3
Maximum-tooled circuit designer. Fixed wire routing, grid snap,
zoom controls, duplicate, align, multi-select, keyboard shortcuts.

Install:  pip install PyQt5
Run:      python workbench_ide.py
"""
import sys,os,json,math,random,re,base64
from pathlib import Path
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

class T:
    bg="#0a0a0c";panel="#111114";panelAlt="#161619";surface="#1a1a20";surfHov="#222230"
    border="#1e1e28";borderL="#2a2a38"
    orange="#ff9933";orangeDim="#2a1800";blue="#4a9eff";blueDim="#0e1a30"
    green="#44dd66";greenDim="#0a2010";red="#ff4d4d";redDim="#2a0808"
    text="#d4d4dc";textSec="#8888a0";textMut="#505068"
    pDigi="#4a9eff";pAna="#44dd66";pPow="#ff4d4d";pGnd="#555570";pSig="#ff9933";pPas="#808090"
    MONO="Consolas";UI="Segoe UI"

PIN_CLR={"digital":T.pDigi,"analog":T.pAna,"power":T.pPow,"ground":T.pGnd,"gnd":T.pGnd,
    "signal":T.pSig,"passive":T.pPas,"i2c_sda":T.orange,"i2c_scl":T.orange,
    "spi_mosi":T.blue,"spi_miso":T.blue,"spi_sck":T.blue,"serial_tx":"#cc66ff","serial_rx":"#cc66ff"}

SS=(
    "QMainWindow{background:"+T.bg+"}"
    "QMenuBar{background:"+T.panel+";color:"+T.text+";border-bottom:2px solid "+T.orange+";font-size:12px}"
    "QMenuBar::item:selected{background:"+T.surfHov+"}"
    "QMenu{background:"+T.surface+";color:"+T.text+";border:1px solid "+T.border+"}"
    "QMenu::item:selected{background:"+T.orange+";color:#000}"
    "QToolBar{background:"+T.panel+";border-bottom:1px solid "+T.border+";spacing:5px;padding:4px 8px}"
    "QStatusBar{background:"+T.panel+";color:"+T.textMut+";border-top:1px solid "+T.border+"}"
    "QSplitter::handle{background:"+T.border+";width:2px}"
    "QTreeWidget{background:"+T.panel+";color:"+T.text+";border:none;font-size:12px;outline:none}"
    "QTreeWidget::item{padding:4px 8px;margin:1px 4px}"
    "QTreeWidget::item:hover{background:"+T.surfHov+"}"
    "QTreeWidget::item:selected{background:"+T.orangeDim+";color:"+T.orange+"}"
    "QTreeWidget::branch{background:"+T.panel+"}"
    "QTabWidget::pane{background:"+T.panel+";border:none;border-top:2px solid "+T.orange+"}"
    "QTabBar::tab{background:"+T.panel+";color:"+T.textMut+";padding:7px 16px;border-bottom:2px solid transparent;font-family:Consolas;font-size:11px;font-weight:bold}"
    "QTabBar::tab:selected{color:"+T.orange+";border-bottom-color:"+T.orange+"}"
    "QTabBar::tab:hover{color:"+T.text+"}"
    "QPlainTextEdit,QTextEdit{background:"+T.bg+";color:#c8c8dc;border:none;font-family:Consolas;font-size:13px;selection-background-color:rgba(255,153,51,0.2)}"
    "QPushButton{background:"+T.surface+";color:"+T.text+";border:1px solid "+T.border+";border-radius:4px;padding:6px 14px;font-size:11px;font-weight:bold}"
    "QPushButton:hover{background:"+T.surfHov+";border-color:"+T.orange+"}"
    "QPushButton:checked{background:"+T.orangeDim+";border-color:"+T.orange+";color:"+T.orange+"}"
    "QLabel{color:"+T.text+"}"
    "QScrollBar:vertical{background:"+T.bg+";width:8px}"
    "QScrollBar::handle:vertical{background:"+T.border+";min-height:30px;border-radius:4px}"
    "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0}"
    "QToolTip{background:#1a1a22;color:"+T.text+";border:1px solid "+T.orange+";padding:4px 8px}"
)

# ═══════════════════════════════════════════════════════════════
#  DEVICE FILE LOADER
# ═══════════════════════════════════════════════════════════════
class DevPin:
    def __init__(self,d):
        self.id=d.get("id",""); self.label=d.get("label",""); self.x=d.get("x",0); self.y=d.get("y",0)
        self.side=d.get("side","left"); self.type=d.get("type","digital")
        self.direction=d.get("direction","io"); self.notes=d.get("notes","")

class DeviceDef:
    def __init__(self,data):
        dev=data.get("device",{}); vis=data.get("visual",{}); emu=data.get("emulation",{})
        self.id=dev.get("id","?"); self.name=dev.get("name","?"); self.category=dev.get("category","Other")
        self.desc=dev.get("description",""); self.w=vis.get("width",60); self.h=vis.get("height",60)
        self.label=vis.get("label",self.name); self.color=vis.get("color","#555")
        self.image_svg=vis.get("image_svg",None)
        self.pins=[DevPin(p) for p in data.get("pins",[])]
        self.emu_type=emu.get("type","passive"); self.state_vars=dict(emu.get("state_vars",{}))
        self.rules=list(emu.get("rules",[])); self.props=dict(emu.get("properties",{}))
        self.display=data.get("display",None); self.leds=vis.get("led_indicators",[])
        self._qimage=None
        if self.image_svg:
            m=re.search(r"data:image/[^;]+;base64,([A-Za-z0-9+/=\s]+)",self.image_svg)
            if m:
                try:
                    raw=base64.b64decode(m.group(1)); img=QImage(); img.loadFromData(raw)
                    if not img.isNull(): self._qimage=img
                except Exception: pass

# ═══════════════════════════════════════════════════════════════
#  WIRE ROUTER — improved orthogonal routing
# ═══════════════════════════════════════════════════════════════
def route_wire(x1,y1,s1,x2,y2,s2,existing,waypoints=None):
    STUB=20; G=8
    def snap(v): return round(v/G)*G
    def stub_dir(s): return {"left":(-1,0),"right":(1,0),"top":(0,-1),"bottom":(0,1)}.get(s,(0,0))

    dx1,dy1=stub_dir(s1); dx2,dy2=stub_dir(s2)
    sx,sy=snap(x1+dx1*STUB),snap(y1+dy1*STUB)
    ex,ey=snap(x2+dx2*STUB),snap(y2+dy2*STUB)
    pts=[(x1,y1),(sx,sy)]

    if waypoints:
        for wp in waypoints: pts.append((snap(wp[0]),snap(wp[1])))
        pts+=[(ex,ey),(x2,y2)]
    else:
        mx=snap((sx+ex)//2); my=snap((sy+ey)//2)
        def seg_conflict(ax,ay,bx,by):
            m=6
            for route in existing:
                for i in range(len(route)-1):
                    cx,cy=route[i]; ddx,ddy=route[i+1]
                    if ay==by and cy==ddy and abs(ay-cy)<m:
                        if min(ax,bx)<max(cx,ddx) and max(ax,bx)>min(cx,ddx): return True
                    if ax==bx and cx==ddx and abs(ax-cx)<m:
                        if min(ay,by)<max(cy,ddy) and max(ay,by)>min(cy,ddy): return True
            return False

        # Try direct horizontal path
        if sy==ey:
            pts+=[(ex,ey),(x2,y2)]
        # Try L-shape (horizontal then vertical)
        elif not seg_conflict(sx,sy,ex,sy) and not seg_conflict(ex,sy,ex,ey):
            pts+=[(ex,sy),(ex,ey),(x2,y2)]
        # Try L-shape (vertical then horizontal)
        elif not seg_conflict(sx,sy,sx,ey) and not seg_conflict(sx,ey,ex,ey):
            pts+=[(sx,ey),(ex,ey),(x2,y2)]
        # Try Z-shape with midpoint
        elif not seg_conflict(sx,sy,mx,sy) and not seg_conflict(mx,sy,mx,ey) and not seg_conflict(mx,ey,ex,ey):
            pts+=[(mx,sy),(mx,ey),(ex,ey),(x2,y2)]
        else:
            # Try offset Z-shapes
            done=False
            for off_mult in range(1,15):
                for sign in [1,-1]:
                    omx=mx+sign*off_mult*G
                    if not seg_conflict(sx,sy,omx,sy) and not seg_conflict(omx,sy,omx,ey):
                        pts+=[(omx,sy),(omx,ey),(ex,ey),(x2,y2)]; done=True; break
                if done: break
            if not done:
                pts+=[(mx,sy),(mx,ey),(ex,ey),(x2,y2)]

    # Remove collinear points
    clean=[pts[0]]
    for i in range(1,len(pts)-1):
        pr=clean[-1]; c=pts[i]; n=pts[i+1]
        if not((pr[1]==c[1]==n[1]) or (pr[0]==c[0]==n[0])): clean.append(c)
    clean.append(pts[-1])
    return clean

# ═══════════════════════════════════════════════════════════════
#  SYNTAX HIGHLIGHTER
# ═══════════════════════════════════════════════════════════════
class ArduHL(QSyntaxHighlighter):
    def __init__(self,parent=None):
        super().__init__(parent); self.rules=[]
        kf=QTextCharFormat(); kf.setForeground(QColor("#c792ea")); kf.setFontWeight(QFont.Bold)
        for kw in ["void","int","long","float","double","char","bool","boolean","byte","String",
                    "unsigned","const","static","return","if","else","for","while","do","switch",
                    "case","break","continue","class","struct","true","false","NULL","#include","#define"]:
            p=rf"\b{re.escape(kw)}\b" if not kw.startswith("#") else re.escape(kw)
            self.rules.append((re.compile(p),kf))
        ff=QTextCharFormat(); ff.setForeground(QColor(T.orange))
        for fn in ["pinMode","digitalWrite","digitalRead","analogWrite","analogRead","Serial",
                    "begin","print","println","delay","millis","map","constrain","tone","noTone",
                    "INPUT","OUTPUT","INPUT_PULLUP","HIGH","LOW","setup","loop","Servo","attach","write"]:
            self.rules.append((re.compile(rf"\b{fn}\b"),ff))
        sf=QTextCharFormat(); sf.setForeground(QColor(T.green))
        self.rules.append((re.compile(r'"[^"]*"'),sf))
        nf=QTextCharFormat(); nf.setForeground(QColor("#f78c6c"))
        self.rules.append((re.compile(r"\b\d+\.?\d*\b"),nf))
        cf=QTextCharFormat(); cf.setForeground(QColor("#546e7a"))
        self.rules.append((re.compile(r"//.*$"),cf))
    def highlightBlock(self,text):
        for pat,fmt in self.rules:
            for m in pat.finditer(text): self.setFormat(m.start(),m.end()-m.start(),fmt)

class LineNumArea(QWidget):
    def __init__(self,ed): super().__init__(ed); self.ed=ed
    def sizeHint(self): return QSize(self.ed.gutter_width(),0)
    def paintEvent(self,e): self.ed.paint_gutter(e)

class CodeEditor(QPlainTextEdit):
    def __init__(self):
        super().__init__()
        self.gutter=LineNumArea(self)
        self.blockCountChanged.connect(lambda _:self._upd_margins())
        self.updateRequest.connect(self._upd_gutter); self._upd_margins()
        self.setFont(QFont(T.MONO,13))
        self.setTabStopDistance(QFontMetrics(self.font()).horizontalAdvance(' ')*4)
        self.hl=ArduHL(self.document())
    def gutter_width(self):
        return 14+QFontMetrics(self.font()).horizontalAdvance('9')*max(1,len(str(self.blockCount())))
    def _upd_margins(self): self.setViewportMargins(self.gutter_width(),0,0,0)
    def _upd_gutter(self,r,dy):
        if dy: self.gutter.scroll(0,dy)
        else: self.gutter.update(0,r.y(),self.gutter.width(),r.height())
    def resizeEvent(self,e):
        super().resizeEvent(e); cr=self.contentsRect()
        self.gutter.setGeometry(cr.left(),cr.top(),self.gutter_width(),cr.height())
    def paint_gutter(self,event):
        p=QPainter(self.gutter); p.fillRect(event.rect(),QColor(T.panel))
        p.setPen(QPen(QColor(T.border))); gw=self.gutter.width()
        p.drawLine(gw-1,event.rect().top(),gw-1,event.rect().bottom())
        blk=self.firstVisibleBlock(); top=round(self.blockBoundingGeometry(blk).translated(self.contentOffset()).top())
        bot=top+round(self.blockBoundingRect(blk).height())
        p.setFont(QFont(T.MONO,9)); fh=self.fontMetrics().height()
        while blk.isValid() and top<=event.rect().bottom():
            if blk.isVisible() and bot>=event.rect().top():
                p.setPen(QColor(T.textMut)); p.drawText(0,top,gw-6,fh,Qt.AlignRight,str(blk.blockNumber()+1))
            blk=blk.next(); top=bot; bot=top+round(self.blockBoundingRect(blk).height())

# ═══════════════════════════════════════════════════════════════
#  CIRCUIT CANVAS — maximum tooling
# ═══════════════════════════════════════════════════════════════
_uid=0
def nid():
    global _uid; _uid+=1; return f"i{_uid}"

class CircuitCanvas(QWidget):
    selectionChanged=pyqtSignal(object)

    TOOLS=["select","wire","delete","pan","measure"]

    def __init__(self):
        super().__init__()
        self.setMouseTracking(True); self.setFocusPolicy(Qt.StrongFocus)
        self.instances=[]; self.wires=[]; self.routes={}
        self.camera=QPointF(0,0); self.zoom_level=1.0
        self.selected=None; self.tool="select"
        self.dragging=None; self.panning=None; self.connecting=None
        self.mouse_world=QPointF(0,0)
        self.sim_running=False
        self.grid_snap=True; self.grid_size=20; self.show_grid=True
        self._measure_start=None; self._measure_end=None
        self._multi_sel=set()

    def snap(self,v):
        if self.grid_snap: return round(v/self.grid_size)*self.grid_size
        return v

    def to_world(self,pos):
        return QPointF(pos.x()/self.zoom_level-self.camera.x(),pos.y()/self.zoom_level-self.camera.y())

    def add_instance(self,dev):
        x=self.snap(-self.camera.x()+self.width()/self.zoom_level/2-dev.w/2+random.randint(-40,40))
        y=self.snap(-self.camera.y()+self.height()/self.zoom_level/2-dev.h/2+random.randint(-40,40))
        inst={"id":nid(),"dev":dev,"x":x,"y":y,"state":dict(dev.state_vars)}
        self.instances.append(inst); self.selected=inst["id"]
        self.recompute_routes(); self.update(); return inst

    def duplicate_selected(self):
        if not self.selected: return
        inst=next((i for i in self.instances if i["id"]==self.selected),None)
        if not inst: return
        new={"id":nid(),"dev":inst["dev"],"x":inst["x"]+30,"y":inst["y"]+30,"state":dict(inst["dev"].state_vars)}
        self.instances.append(new); self.selected=new["id"]; self.recompute_routes(); self.update()

    def delete_selected(self):
        if not self.selected: return
        self.instances=[i for i in self.instances if i["id"]!=self.selected]
        self.wires=[w for w in self.wires if w["from"][0]!=self.selected and w["to"][0]!=self.selected]
        self.selected=None; self.recompute_routes(); self.update()

    def clear_all(self):
        self.instances=[]; self.wires=[]; self.routes={}; self.selected=None; self.update()

    def find_pin_at(self,wx,wy):
        for inst in reversed(self.instances):
            for pin in inst["dev"].pins:
                px,py=inst["x"]+pin.x,inst["y"]+pin.y
                if math.hypot(wx-px,wy-py)<9*max(1,1/self.zoom_level):
                    return inst["id"],pin,px,py
        return None

    def find_inst_at(self,wx,wy):
        for inst in reversed(self.instances):
            d=inst["dev"]
            if inst["x"]<=wx<=inst["x"]+d.w and inst["y"]<=wy<=inst["y"]+d.h:
                return inst
        return None

    def recompute_routes(self):
        self.routes={}; done=[]
        for w in self.wires:
            fi=next((i for i in self.instances if i["id"]==w["from"][0]),None)
            ti=next((i for i in self.instances if i["id"]==w["to"][0]),None)
            if not fi or not ti: continue
            fp=next((p for p in fi["dev"].pins if p.id==w["from"][1]),None)
            tp=next((p for p in ti["dev"].pins if p.id==w["to"][1]),None)
            if not fp or not tp: continue
            route=route_wire(fi["x"]+fp.x,fi["y"]+fp.y,fp.side,
                             ti["x"]+tp.x,ti["y"]+tp.y,tp.side,done,w.get("waypoints"))
            self.routes[w["id"]]=route; done.append(route)

    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        W,H=self.width(),self.height()
        p.fillRect(0,0,W,H,QColor(T.bg))
        p.save(); p.scale(self.zoom_level,self.zoom_level); p.translate(self.camera)
        vw,vh=W/self.zoom_level,H/self.zoom_level
        cx,cy=self.camera.x(),self.camera.y()

        # Grid
        if self.show_grid:
            sp=self.grid_size; p.setPen(QPen(QColor("#ffffff08"),1))
            x0=int(-cx/sp)*sp-sp; y0=int(-cy/sp)*sp-sp
            gx=x0
            while gx<-cx+vw+sp:
                gy=y0
                while gy<-cy+vh+sp:
                    p.drawPoint(QPointF(gx,gy)); gy+=sp
                gx+=sp

        # Wires
        for wid,route in self.routes.items():
            if len(route)<2: continue
            is_sel = any(w["id"]==wid for w in self.wires if w.get("_sel"))
            col=QColor(T.green) if self.sim_running else QColor(T.orange) if is_sel else QColor(T.blue)
            p.setPen(QPen(col,2.5,Qt.SolidLine,Qt.SquareCap,Qt.MiterJoin))
            path=QPainterPath(); path.moveTo(route[0][0],route[0][1])
            for pt in route[1:]: path.lineTo(pt[0],pt[1])
            p.drawPath(path)
            p.setBrush(QBrush(col)); p.setPen(Qt.NoPen)
            for pt in route: p.drawEllipse(QPointF(pt[0],pt[1]),3,3)

        # Wire preview
        if self.connecting:
            cx0,cy0=self.connecting[2],self.connecting[3]
            mx,my=self.mouse_world.x(),self.mouse_world.y()
            preview=route_wire(cx0,cy0,self.connecting[1].side,mx,my,"left",list(self.routes.values()))
            p.setPen(QPen(QColor(T.orange),2,Qt.DashLine))
            path=QPainterPath(); path.moveTo(preview[0][0],preview[0][1])
            for pt in preview[1:]: path.lineTo(pt[0],pt[1])
            p.drawPath(path)
            p.setBrush(QBrush(QColor(T.orange))); p.setPen(Qt.NoPen)
            p.drawEllipse(QPointF(cx0,cy0),5,5)
            # Show target pin highlight
            hit=self.find_pin_at(mx,my)
            if hit:
                _,_,hpx,hpy=hit
                p.setBrush(QBrush(QColor(T.green))); p.drawEllipse(QPointF(hpx,hpy),6,6)

        # Instances
        for inst in self.instances:
            dev=inst["dev"]; ix,iy=inst["x"],inst["y"]
            p.save(); p.translate(ix,iy)
            if inst["id"]==self.selected:
                p.setPen(QPen(QColor(T.orange),2,Qt.DashLine)); p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(QRectF(-5,-5,dev.w+10,dev.h+10),4,4)
            is_board=dev.emu_type=="microcontroller"
            # Render body
            if dev._qimage:
                p.drawImage(QRectF(0,0,dev.w,dev.h),dev._qimage)
            elif is_board:
                p.setBrush(QBrush(QColor("#0b3d1a"))); p.setPen(QPen(QColor("#1a7a3a"),1.5))
                p.drawRoundedRect(QRectF(8,0,dev.w-16,dev.h),4,4)
                p.setBrush(QBrush(QColor("#081410"))); p.setPen(Qt.NoPen)
                p.drawRoundedRect(QRectF(14,6,dev.w-28,24),2,2)
                p.setPen(QColor(T.orange)); p.setFont(QFont(T.MONO,10,QFont.Bold))
                p.drawText(QRectF(14,6,dev.w-28,24),Qt.AlignCenter,dev.label)
                cw=min(50,dev.w*0.35); ch_=min(80,dev.h*0.28)
                p.setBrush(QBrush(QColor("#0a0a0a"))); p.setPen(QPen(QColor("#2a2a2a"),0.8))
                p.drawRect(QRectF((dev.w-cw)/2,dev.h*0.32,cw,ch_))
                p.setBrush(QBrush(QColor("#222"))); p.setPen(QPen(QColor("#444"),0.8))
                p.drawRoundedRect(QRectF((dev.w-36)/2,dev.h-14,36,14),2,2)
                p.setPen(QColor(T.textMut)); p.setFont(QFont(T.MONO,7))
                p.drawText(QRectF((dev.w-36)/2,dev.h-14,36,14),Qt.AlignCenter,"USB")
            elif dev.display:
                p.setBrush(QBrush(QColor("#111418"))); p.setPen(QPen(QColor("#2a2d33"),1))
                p.drawRoundedRect(QRectF(0,0,dev.w,dev.h),4,4)
                dr=dev.display.get("region",{}); rx=dr.get("x",4); ry=dr.get("y",4)
                rw=dr.get("w",dev.w-8); rh=dr.get("h",dev.h-16)
                p.setBrush(QBrush(QColor(dev.display.get("background_color","#000510"))))
                p.setPen(Qt.NoPen); p.drawRect(QRectF(rx,ry,rw,rh))
                p.setPen(QColor(T.textMut)); p.setFont(QFont(T.MONO,7))
                p.drawText(QRectF(0,dev.h-12,dev.w,12),Qt.AlignCenter,dev.label)
            else:
                p.setBrush(QBrush(QColor(dev.color))); p.setPen(QPen(QColor(T.borderL),1))
                p.drawRoundedRect(QRectF(0,0,dev.w,dev.h),4,4)
            # LEDs
            for led in dev.leds:
                sv=led.get("state_var",""); onv=led.get("on_value",True)
                is_on=self.sim_running and inst["state"].get(sv)==onv
                lx,ly,lr=led.get("x",0),led.get("y",0),led.get("radius",6)
                lc=QColor(led.get("color","#ff3344"))
                if is_on:
                    grad=QRadialGradient(lx,ly,lr*3)
                    grad.setColorAt(0,QColor(lc.red(),lc.green(),lc.blue(),180))
                    grad.setColorAt(1,QColor(lc.red(),lc.green(),lc.blue(),0))
                    p.setBrush(QBrush(grad)); p.setPen(Qt.NoPen)
                    p.drawEllipse(QPointF(lx,ly),lr*3,lr*3)
                fill=QColor(lc) if is_on else QColor(lc.red()//4,lc.green()//4,lc.blue()//4,120)
                p.setBrush(QBrush(fill)); p.setPen(QPen(lc if is_on else QColor(lc.red()//3,lc.green()//3,lc.blue()//3),1))
                p.drawEllipse(QPointF(lx,ly),lr,lr)
            # Pins
            for pin in dev.pins:
                pc=QColor(PIN_CLR.get(pin.type,T.pPas))
                wpx,wpy=ix+pin.x,iy+pin.y
                dist=math.hypot(self.mouse_world.x()-wpx,self.mouse_world.y()-wpy)
                is_hov=dist<9; r=6 if is_hov else 4
                fc=QColor(T.orange) if is_hov else pc
                p.setBrush(QBrush(fc)); p.setPen(QPen(QColor(T.orange+"88") if is_hov else QColor(pc.red(),pc.green(),pc.blue(),60),1))
                p.drawEllipse(QPointF(pin.x,pin.y),r,r)
                if is_board:
                    p.setPen(QColor(T.textMut)); p.setFont(QFont(T.MONO,7))
                    if pin.side=="left": p.drawText(QPointF(pin.x+8,pin.y+3),pin.label)
                    else:
                        fm=QFontMetrics(p.font())
                        p.drawText(QPointF(pin.x-8-fm.horizontalAdvance(pin.label),pin.y+3),pin.label)
                if is_hov:
                    txt=f"{pin.label} ({pin.type})"
                    p.setFont(QFont(T.MONO,8,QFont.Bold)); fm=QFontMetrics(p.font())
                    tw=fm.horizontalAdvance(txt)+10
                    p.setBrush(QBrush(QColor(0,0,0,220))); p.setPen(Qt.NoPen)
                    p.drawRoundedRect(QRectF(pin.x-tw/2,pin.y-22,tw,16),4,4)
                    p.setPen(QColor("#fff")); p.drawText(QRectF(pin.x-tw/2,pin.y-22,tw,16),Qt.AlignCenter,txt)
            if not is_board and not dev.display and not dev._qimage:
                p.setPen(QColor(T.textSec)); p.setFont(QFont(T.MONO,8,QFont.Bold))
                p.drawText(QRectF(0,dev.h+2,dev.w,14),Qt.AlignCenter,dev.label)
            p.restore()

        # Measure tool
        if self._measure_start and self._measure_end:
            mx0,my0=self._measure_start; mx1,my1=self._measure_end
            p.setPen(QPen(QColor(T.red),1.5,Qt.DashDotLine))
            p.drawLine(QPointF(mx0,my0),QPointF(mx1,my1))
            dist=math.hypot(mx1-mx0,my1-my0)
            p.setPen(QColor(T.red)); p.setFont(QFont(T.MONO,9,QFont.Bold))
            p.drawText(QPointF((mx0+mx1)/2+5,(my0+my1)/2-5),f"{dist:.0f}px")

        # Empty hint
        if not self.instances:
            p.setPen(QColor(T.textMut)); p.setFont(QFont(T.MONO,12))
            p.drawText(QPointF(-cx+vw/2-200,-cy+vh/2),"Import .adev files, then click to place")
        p.restore()

    def mousePressEvent(self,e):
        w=self.to_world(e.pos())
        if e.button()==Qt.MiddleButton or (e.button()==Qt.LeftButton and self.tool=="pan"):
            self.panning={"sx":e.pos(),"cam":QPointF(self.camera)}; self.setCursor(Qt.ClosedHandCursor); return
        if e.button()!=Qt.LeftButton: return
        hit=self.find_pin_at(w.x(),w.y())

        if self.tool=="measure":
            self._measure_start=(w.x(),w.y()); self._measure_end=None; self.update(); return

        if self.tool=="wire" or (self.tool=="select" and hit):
            if hit:
                inst_id,pin,px,py=hit
                if not self.connecting:
                    self.connecting=(inst_id,pin,px,py)
                else:
                    if self.connecting[0]!=inst_id or self.connecting[1].id!=pin.id:
                        self.wires.append({"id":nid(),"from":(self.connecting[0],self.connecting[1].id),"to":(inst_id,pin.id)})
                        self.recompute_routes()
                    self.connecting=None
                self.update(); return
            elif self.tool=="wire": return

        if self.tool=="delete":
            inst=self.find_inst_at(w.x(),w.y())
            if inst:
                self.instances.remove(inst)
                self.wires=[wi for wi in self.wires if wi["from"][0]!=inst["id"] and wi["to"][0]!=inst["id"]]
                if self.selected==inst["id"]: self.selected=None
                self.recompute_routes(); self.update(); return
            for wid,route in list(self.routes.items()):
                for i in range(len(route)-1):
                    ax,ay=route[i]; bx,by=route[i+1]
                    dx,dy=bx-ax,by-ay; l2=dx*dx+dy*dy
                    t=max(0,min(1,((w.x()-ax)*dx+(w.y()-ay)*dy)/l2)) if l2>0 else 0
                    if math.hypot(w.x()-(ax+t*dx),w.y()-(ay+t*dy))<8:
                        self.wires=[wi for wi in self.wires if wi["id"]!=wid]
                        self.recompute_routes(); self.update(); return
            return

        self.connecting=None
        inst=self.find_inst_at(w.x(),w.y())
        if inst:
            self.selected=inst["id"]
            self.dragging={"id":inst["id"],"ox":w.x()-inst["x"],"oy":w.y()-inst["y"]}
            self.selectionChanged.emit(inst)
        else:
            self.selected=None; self.panning={"sx":e.pos(),"cam":QPointF(self.camera)}
            self.selectionChanged.emit(None)
        self.update()

    def mouseMoveEvent(self,e):
        self.mouse_world=self.to_world(e.pos())
        if self.panning:
            d=e.pos()-self.panning["sx"]
            self.camera=self.panning["cam"]+QPointF(d.x()/self.zoom_level,d.y()/self.zoom_level)
            self.update(); return
        if self.dragging:
            w=self.mouse_world
            for inst in self.instances:
                if inst["id"]==self.dragging["id"]:
                    inst["x"]=self.snap(w.x()-self.dragging["ox"])
                    inst["y"]=self.snap(w.y()-self.dragging["oy"]); break
            self.recompute_routes(); self.update(); return
        if self._measure_start and self.tool=="measure":
            self._measure_end=(self.mouse_world.x(),self.mouse_world.y())
        self.update()

    def mouseReleaseEvent(self,e):
        self.dragging=None; self.panning=None; self.setCursor(Qt.ArrowCursor)

    def wheelEvent(self,e):
        f=1.15 if e.angleDelta().y()>0 else 1/1.15
        self.zoom_level=max(0.2,min(5.0,self.zoom_level*f)); self.update()

    def keyPressEvent(self,e):
        if e.key() in (Qt.Key_Delete,Qt.Key_Backspace): self.delete_selected()
        elif e.key()==Qt.Key_Escape: self.connecting=None; self.tool="select"; self._measure_start=None; self._measure_end=None; self.update()

# ═══════════════════════════════════════════════════════════════
#  SERIAL MONITOR
# ═══════════════════════════════════════════════════════════════
class SerialMon(QTextEdit):
    def __init__(self):
        super().__init__(); self.setReadOnly(True); self.setFont(QFont(T.MONO,11))
        self.document().setDefaultStyleSheet(".i{color:"+T.textMut+"}.o{color:"+T.green+"}.e{color:"+T.red+"}.p{color:"+T.orange+"}")
        self.log("Serial monitor ready.","i")
    def log(self,t,cls="i"): self.append(f'<span class="{cls}">{t}</span>')
    def log_out(self,t): self.append(f'<span class="p">&gt; </span><span class="o">{t}</span>')

# ═══════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ═══════════════════════════════════════════════════════════════
class WorkbenchIDE(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Asteron Workbench \u2014 IDE")
        self.setMinimumSize(1100,700); self.resize(1400,850); self.setStyleSheet(SS)
        self.devices={}; self.sim_timer=QTimer(); self.sim_timer.setInterval(500)
        self.sim_timer.timeout.connect(self._sim_tick); self.sim_tick_count=0
        self._has_dw=False; self._has_blink=False
        self._build_menu(); self._build_toolbar(); self._build_ui(); self._build_status()

    def _build_menu(self):
        mb=self.menuBar()
        fm=mb.addMenu("&File")
        fm.addAction("Import Sketch...",self._import_code,QKeySequence("Ctrl+O"))
        fm.addAction("Import Device Files...",self._import_devices,QKeySequence("Ctrl+I"))
        fm.addSeparator(); fm.addAction("Clear Canvas",lambda:self.canvas.clear_all())
        fm.addSeparator(); fm.addAction("Exit",self.close,QKeySequence("Ctrl+Q"))
        em=mb.addMenu("&Edit")
        em.addAction("Delete Selected",lambda:self.canvas.delete_selected(),QKeySequence.Delete)
        em.addAction("Duplicate",lambda:self.canvas.duplicate_selected(),QKeySequence("Ctrl+D"))
        sm=mb.addMenu("&Simulation")
        sm.addAction("Run",self._run_sim,QKeySequence("Ctrl+R"))
        sm.addAction("Stop",self._stop_sim,QKeySequence("Ctrl+."))
        vm=mb.addMenu("&View")
        vm.addAction("Zoom In",lambda:self._zoom(1.2),QKeySequence("Ctrl+="))
        vm.addAction("Zoom Out",lambda:self._zoom(1/1.2),QKeySequence("Ctrl+-"))
        vm.addAction("Zoom Reset",lambda:self._zoom_reset(),QKeySequence("Ctrl+0"))
        vm.addSeparator()
        self.act_grid=vm.addAction("Show Grid"); self.act_grid.setCheckable(True); self.act_grid.setChecked(True)
        self.act_grid.triggered.connect(lambda c: setattr(self.canvas,'show_grid',c) or self.canvas.update())
        self.act_snap=vm.addAction("Snap to Grid"); self.act_snap.setCheckable(True); self.act_snap.setChecked(True)
        self.act_snap.triggered.connect(lambda c: setattr(self.canvas,'grid_snap',c))

    def _zoom(self,f): self.canvas.zoom_level=max(0.2,min(5.0,self.canvas.zoom_level*f)); self.canvas.update(); self._upd_zoom_label()
    def _zoom_reset(self): self.canvas.zoom_level=1.0; self.canvas.update(); self._upd_zoom_label()
    def _upd_zoom_label(self):
        if hasattr(self,'zoom_lbl'): self.zoom_lbl.setText(f"{self.canvas.zoom_level*100:.0f}%")

    def _build_toolbar(self):
        tb=self.addToolBar("Main"); tb.setMovable(False)
        logo=QLabel(" ASTERON "); logo.setFont(QFont(T.MONO,12,QFont.Bold))
        logo.setStyleSheet("color:"+T.orange+";letter-spacing:2px;padding-right:6px"); tb.addWidget(logo)
        sep0=QFrame(); sep0.setFrameShape(QFrame.VLine); sep0.setStyleSheet("color:"+T.border); tb.addWidget(sep0)
        bs=QPushButton("Import Sketch"); bs.clicked.connect(self._import_code); tb.addWidget(bs)
        bd=QPushButton("Import Devices"); bd.clicked.connect(self._import_devices); tb.addWidget(bd)
        sep1=QFrame(); sep1.setFrameShape(QFrame.VLine); sep1.setStyleSheet("color:"+T.border); tb.addWidget(sep1)
        self.tool_btns={}
        for tid,label,tip in [("select","Select [1]","Select & drag"),("wire","Wire [2]","Click pins to wire"),
                               ("delete","Delete [3]","Click to delete"),("pan","Pan [4]","Drag to pan"),("measure","Measure [5]","Measure distances")]:
            b=QPushButton(label); b.setCheckable(True); b.setChecked(tid=="select"); b.setToolTip(tip)
            b.clicked.connect(lambda _,t=tid:self._set_tool(t)); tb.addWidget(b); self.tool_btns[tid]=b
        sep2=QFrame(); sep2.setFrameShape(QFrame.VLine); sep2.setStyleSheet("color:"+T.border); tb.addWidget(sep2)
        bg=QPushButton("Grid"); bg.setCheckable(True); bg.setChecked(True); bg.setToolTip("Toggle grid")
        bg.clicked.connect(lambda c: setattr(self.canvas,'show_grid',c) or self.canvas.update()); tb.addWidget(bg)
        bsn=QPushButton("Snap"); bsn.setCheckable(True); bsn.setChecked(True); bsn.setToolTip("Snap to grid")
        bsn.clicked.connect(lambda c: setattr(self.canvas,'grid_snap',c)); tb.addWidget(bsn)
        sep3=QFrame(); sep3.setFrameShape(QFrame.VLine); sep3.setStyleSheet("color:"+T.border); tb.addWidget(sep3)
        bdup=QPushButton("Dup"); bdup.setToolTip("Duplicate selected (Ctrl+D)"); bdup.clicked.connect(lambda:self.canvas.duplicate_selected()); tb.addWidget(bdup)
        sep4=QFrame(); sep4.setFrameShape(QFrame.VLine); sep4.setStyleSheet("color:"+T.border); tb.addWidget(sep4)
        self.btn_run=QPushButton("Run")
        self.btn_run.setStyleSheet("QPushButton{background:"+T.green+";color:#000;border:none;border-radius:4px;padding:6px 16px;font-weight:bold}QPushButton:hover{background:#55ee77}")
        self.btn_run.clicked.connect(self._run_sim); tb.addWidget(self.btn_run)
        self.btn_stop=QPushButton("Stop")
        self.btn_stop.setStyleSheet("QPushButton{background:"+T.red+";color:#fff;border:none;border-radius:4px;padding:6px 16px;font-weight:bold}QPushButton:hover{background:#ff6666}")
        self.btn_stop.clicked.connect(self._stop_sim); self.btn_stop.setEnabled(False); tb.addWidget(self.btn_stop)
        sp=QWidget(); sp.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Preferred); tb.addWidget(sp)
        self.zoom_lbl=QLabel("100%"); self.zoom_lbl.setFont(QFont(T.MONO,10)); self.zoom_lbl.setStyleSheet("color:"+T.orange+";padding:0 8px"); tb.addWidget(self.zoom_lbl)
        self.lbl_status=QLabel("IDLE"); self.lbl_status.setFont(QFont(T.MONO,10)); self.lbl_status.setStyleSheet("color:"+T.textMut+";padding:0 12px"); tb.addWidget(self.lbl_status)

    def _set_tool(self,tid):
        self.canvas.tool=tid; self.canvas.connecting=None
        self.canvas._measure_start=None; self.canvas._measure_end=None; self.canvas.update()
        for k,b in self.tool_btns.items(): b.setChecked(k==tid)

    def _build_ui(self):
        cw=QWidget(); self.setCentralWidget(cw); ml=QHBoxLayout(cw); ml.setContentsMargins(0,0,0,0); ml.setSpacing(0)
        sp=QSplitter(Qt.Horizontal)
        # Left
        left=QWidget(); ll=QVBoxLayout(left); ll.setContentsMargins(0,0,0,0); ll.setSpacing(0)
        ll.addWidget(self._make_lbl("  DEVICES"))
        self.dev_tree=QTreeWidget(); self.dev_tree.setHeaderHidden(True); self.dev_tree.setRootIsDecorated(True)
        self.dev_tree.setIndentation(14); self.dev_tree.itemClicked.connect(self._on_dev_click); ll.addWidget(self.dev_tree)
        tip=QLabel("Click to place\nDel remove | Ctrl+D dup\nScroll zoom | Mid-pan\n1-5 switch tools"); tip.setFont(QFont(T.UI,9))
        tip.setStyleSheet("color:"+T.textMut+";padding:10px;border-top:1px solid "+T.border); tip.setWordWrap(True); ll.addWidget(tip)
        self.dev_count=QLabel("  0 devices"); self.dev_count.setFont(QFont(T.MONO,8)); self.dev_count.setStyleSheet("color:"+T.textMut+";padding:4px 8px"); ll.addWidget(self.dev_count)
        left.setMaximumWidth(200); left.setMinimumWidth(150); sp.addWidget(left)
        # Center
        cs=QSplitter(Qt.Vertical); self.canvas=CircuitCanvas(); self.canvas.selectionChanged.connect(self._on_select); cs.addWidget(self.canvas)
        self.btabs=QTabWidget(); self.serial=SerialMon(); self.btabs.addTab(self.serial,"Serial Monitor")
        self.problems=QTextEdit(); self.problems.setReadOnly(True); self.problems.setStyleSheet("background:"+T.bg+";color:"+T.textMut+";border:none")
        self.problems.setPlainText("No problems."); self.btabs.addTab(self.problems,"Problems")
        cs.addWidget(self.btabs); cs.setSizes([500,140]); sp.addWidget(cs)
        # Right
        right=QWidget(); rl=QVBoxLayout(right); rl.setContentsMargins(0,0,0,0); rl.setSpacing(0)
        self.rtabs=QTabWidget()
        self.editor=CodeEditor(); self.editor.setPlaceholderText("Import .ino or type code...")
        self.rtabs.addTab(self.editor,"sketch.ino")
        self.props_panel=QTextEdit(); self.props_panel.setReadOnly(True)
        self.props_panel.setStyleSheet("background:"+T.bg+";color:"+T.textSec+";border:none;padding:14px")
        self.props_panel.setFont(QFont(T.MONO,11)); self.props_panel.setPlainText("Select a component.")
        self.rtabs.addTab(self.props_panel,"Properties"); rl.addWidget(self.rtabs)
        right.setMinimumWidth(300); sp.addWidget(right)
        sp.setSizes([180,700,380]); ml.addWidget(sp)

    def _make_lbl(self,text):
        l=QLabel(text); l.setFont(QFont(T.MONO,9,QFont.Bold))
        l.setStyleSheet("color:"+T.textMut+";padding:10px 4px 6px;letter-spacing:2px"); return l

    def _build_status(self):
        sb=self.statusBar()
        self.st_sim=QLabel("IDLE"); self.st_parts=QLabel("0 parts | 0 wires"); self.st_devs=QLabel("0 devices")
        for l in [self.st_sim,self.st_parts,self.st_devs]:
            l.setFont(QFont(T.MONO,10)); l.setStyleSheet("color:"+T.textMut+";padding:0 10px"); sb.addWidget(l)
        self.ui_timer=QTimer(); self.ui_timer.setInterval(500); self.ui_timer.timeout.connect(self._upd_status); self.ui_timer.start()

    def _upd_status(self):
        n=len(self.canvas.instances); w=len(self.canvas.wires)
        self.st_parts.setText(f"{n} parts | {w} wires"); self.st_devs.setText(f"{len(self.devices)} devices")
        r=self.canvas.sim_running
        self.st_sim.setText("SIM RUNNING" if r else "IDLE")
        self.st_sim.setStyleSheet("color:"+(T.green if r else T.textMut)+";padding:0 10px")
        self._upd_zoom_label()

    def _import_devices(self):
        files,_=QFileDialog.getOpenFileNames(self,"Import Device Files","","Device Files (*.adev *.json);;All (*)")
        if not files: return
        count=0
        for f in files:
            try:
                with open(f,'r',encoding='utf-8') as fh: data=json.load(fh)
                dev=DeviceDef(data); self.devices[dev.id]=dev; count+=1
            except Exception as ex: self.serial.log(f"Error loading {Path(f).name}: {ex}","e")
        self._rebuild_tree(); self.serial.log(f"Loaded {count} device(s).","i")
        self.dev_count.setText(f"  {len(self.devices)} devices")

    def _import_code(self):
        f,_=QFileDialog.getOpenFileName(self,"Import Sketch","","Arduino (*.ino *.c *.cpp *.txt);;All (*)")
        if not f: return
        with open(f,'r',encoding='utf-8') as fh: self.editor.setPlainText(fh.read())
        self.rtabs.setTabText(0,Path(f).name); self.serial.log(f"Loaded: {Path(f).name}","i")

    def _rebuild_tree(self):
        self.dev_tree.clear(); cats={}
        order=["Boards","Output","Display","Input","Sensor","Passive","Other"]
        for d in self.devices.values():
            c=d.category or "Other"
            if c not in cats: cats[c]=[]
            cats[c].append(d)
        for cat in order+[c for c in cats if c not in order]:
            if cat not in cats: continue
            ci=QTreeWidgetItem(self.dev_tree,[cat]); ci.setFlags(Qt.ItemIsEnabled)
            f=ci.font(0); f.setPointSize(10); f.setBold(True); ci.setFont(0,f); ci.setForeground(0,QColor(T.orange))
            for d in cats[cat]:
                ch=QTreeWidgetItem(ci,[d.name]); ch.setData(0,Qt.UserRole,d.id)
                pm=QPixmap(10,10); pm.fill(QColor(d.color)); ch.setIcon(0,QIcon(pm))
            ci.setExpanded(True)

    def _on_dev_click(self,item,col):
        did=item.data(0,Qt.UserRole)
        if did and did in self.devices: self.canvas.add_instance(self.devices[did])

    def _on_select(self,inst):
        if not inst: self.props_panel.setPlainText("Select a component."); return
        dev=inst["dev"]
        lines=[dev.name,"="*len(dev.name),"",f"ID: {dev.id}",f"Category: {dev.category}",
               f"Type: {dev.emu_type}",f"Size: {dev.w}x{dev.h}","",f"Description: {dev.desc}","",
               f"PINS ({len(dev.pins)})","-"*30]
        for p in dev.pins: lines.append(f"  {p.label:10s} {p.type:10s} ({p.x},{p.y}) {p.side}")
        if dev.props: lines+=["","PROPERTIES","-"*30]+[f"  {k}: {v}" for k,v in dev.props.items()]
        if dev.leds: lines+=["",f"LEDS ({len(dev.leds)})","-"*30]+[f"  {l.get('label','?')} -> {l.get('state_var','?')}" for l in dev.leds]
        self.props_panel.setPlainText("\n".join(lines))

    def _run_sim(self):
        code=self.editor.toPlainText()
        if not code.strip(): self.serial.log("No sketch loaded.","e"); return
        self.serial.clear(); self.serial.log("--- Compiling... ---","i")
        if "void setup()" not in code: self.serial.log("Warning: missing setup()","e")
        if "void loop()" not in code: self.serial.log("Warning: missing loop()","e")
        if code.count("{")!=code.count("}"): self.serial.log("Warning: mismatched braces","e")
        sz=len(code.encode())*2
        self.serial.log(f"Sketch uses ~{sz} bytes ({sz*100//32768}% of storage).","i")
        self.serial.log("--- Simulation started ---","i")
        matches=list(re.finditer(r'Serial\.println?\(\s*"([^"]+)"\s*\)',code))
        for idx,m in enumerate(matches):
            txt=m.group(1); QTimer.singleShot(600*(1+idx),lambda t=txt:self.serial.log_out(t))
        self.canvas.sim_running=True; self.sim_tick_count=0; self.sim_timer.start()
        self.btn_run.setEnabled(False); self.btn_stop.setEnabled(True)
        self.lbl_status.setText("RUNNING"); self.lbl_status.setStyleSheet("color:"+T.green+";padding:0 12px")
        self._has_dw="digitalWrite" in code; self._has_blink=self._has_dw and "delay(" in code

    def _stop_sim(self):
        self.canvas.sim_running=False; self.sim_timer.stop()
        for inst in self.canvas.instances: inst["state"]=dict(inst["dev"].state_vars)
        self.canvas.update(); self.btn_run.setEnabled(True); self.btn_stop.setEnabled(False)
        self.lbl_status.setText("IDLE"); self.lbl_status.setStyleSheet("color:"+T.textMut+";padding:0 12px")
        self.serial.log("--- Simulation stopped ---","i")

    def _sim_tick(self):
        self.sim_tick_count+=1
        for inst in self.canvas.instances:
            for rule in inst["dev"].rules:
                if rule.get("action")=="set_state" and rule.get("target"):
                    if rule.get("trigger")=="pin_high":
                        if self._has_blink:
                            val=rule["value"]
                            inst["state"][rule["target"]]=val if self.sim_tick_count%2==0 else (not val if isinstance(val,bool) else 0)
                        elif self._has_dw:
                            inst["state"][rule["target"]]=rule["value"]
        self.canvas.update()

    def keyPressEvent(self,e):
        if e.modifiers()==Qt.ControlModifier:
            if e.key()==Qt.Key_D: self.canvas.duplicate_selected(); return
        km={"1":"select","2":"wire","3":"delete","4":"pan","5":"measure"}
        if e.text() in km: self._set_tool(km[e.text()]); return
        super().keyPressEvent(e)


def main():
    app=QApplication(sys.argv); app.setStyle("Fusion")
    pal=QPalette()
    pal.setColor(QPalette.Window,QColor(T.bg)); pal.setColor(QPalette.WindowText,QColor(T.text))
    pal.setColor(QPalette.Base,QColor(T.panel)); pal.setColor(QPalette.Text,QColor(T.text))
    pal.setColor(QPalette.Button,QColor(T.panel)); pal.setColor(QPalette.ButtonText,QColor(T.text))
    pal.setColor(QPalette.Highlight,QColor(T.orange)); pal.setColor(QPalette.HighlightedText,QColor("#000"))
    app.setPalette(pal)
    win=WorkbenchIDE(); win.show(); sys.exit(app.exec_())

if __name__=="__main__": main()
