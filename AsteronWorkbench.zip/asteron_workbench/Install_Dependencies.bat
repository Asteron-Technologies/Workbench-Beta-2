@echo off
title Asteron Workbench - Setup
echo Installing PyQt5...
pip install PyQt5
echo Done!
pause
