#!/usr/bin/env python3
"""
Asteron Workbench — Device Creator (Advanced)
Build .adev device files with full visual editing.

Features:
  - Drag pins & LEDs to reposition
  - Canvas pan (middle-click / Space+drag) & zoom (scroll wheel)
  - Grid snap with toggle (G key)
  - Image resize, fit modes, opacity
  - Right-click context menus
  - Keyboard shortcuts (Del, Ctrl+Z, Ctrl+D, Ctrl+S)
  - Pin auto-layout along edges
  - Undo/redo stack

Install:  pip install PyQt5
Run:      python workbench_device_creator.py
"""
import sys
import os
import json
import math
import copy
import base64
from pathlib import Path
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QSpinBox, QComboBox, QCheckBox,
    QPlainTextEdit, QTextEdit, QTabWidget, QStackedWidget, QListWidget,
    QScrollArea, QFileDialog, QMessageBox, QColorDialog, QFrame,
    QSizePolicy, QStatusBar, QSlider, QMenu, QAction, QToolTip,
    QGridLayout
)
from PyQt5.QtCore import (
    Qt, QTimer, QPointF, QRectF, pyqtSignal, QPoint, QSize
)
from PyQt5.QtGui import (
    QPainter, QColor, QFont, QPen, QBrush, QRadialGradient,
    QImage, QPalette, QFontMetrics, QPainterPath, QPixmap, QCursor
)


# ═══════════════════════════════════════════════════════════════
#  THEME
# ═══════════════════════════════════════════════════════════════
class T:
    bg = "#0c0c0e"
    panel = "#131316"
    panelAlt = "#18181c"
    surface = "#1c1c22"
    surfHov = "#242430"
    border = "#222230"
    borderL = "#2a2a38"
    blue = "#4a9eff"
    blueDim = "#1a2844"
    red = "#ff4d4d"
    green = "#44dd66"
    orange = "#ff9933"
    purple = "#b07aff"
    text = "#d4d4dc"
    textSec = "#8888a0"
    textMut = "#505068"
    MONO = "Consolas"
    UI = "Segoe UI"
    R = 4


PIN_CLR = {
    "digital": T.blue, "analog": T.green, "power": T.red,
    "ground": "#666680", "gnd": "#666680", "signal": T.orange,
    "passive": "#808090", "i2c_sda": T.orange, "i2c_scl": T.orange,
    "spi_mosi": T.blue, "spi_miso": T.blue, "spi_sck": T.blue,
    "serial_tx": T.purple, "serial_rx": T.purple,
}
PIN_TYPES = [
    "digital", "analog", "power", "ground", "signal", "passive",
    "i2c_sda", "i2c_scl", "spi_mosi", "spi_miso", "spi_sck",
    "serial_tx", "serial_rx",
]
PIN_DIRS = ["io", "in", "out"]
PIN_SIDES = ["left", "right", "top", "bottom"]
CATEGORIES = [
    "Boards", "Output", "Display", "Input", "Sensor",
    "Passive", "Communication", "Other",
]

SS = (
    "QMainWindow{background:" + T.bg + "}"
    "QStatusBar{background:" + T.panel + ";color:" + T.textMut
    + ";border-top:1px solid " + T.border + "}"
    "QTabWidget::pane{background:" + T.panel
    + ";border:none;border-top:1px solid " + T.border + "}"
    "QTabBar::tab{background:" + T.panel + ";color:" + T.textMut
    + ";padding:8px 18px;border-bottom:2px solid transparent;"
    "font-family:Consolas;font-size:11px}"
    "QTabBar::tab:selected{color:" + T.blue
    + ";border-bottom-color:" + T.blue + "}"
    "QTabBar::tab:hover{color:" + T.text + "}"
    "QPushButton{background:" + T.surface + ";color:" + T.text
    + ";border:1px solid " + T.border
    + ";border-radius:4px;padding:5px 12px;font-size:11px;font-weight:bold}"
    "QPushButton:hover{background:" + T.surfHov
    + ";border-color:" + T.blue + "}"
    "QPushButton:checked{background:" + T.blueDim
    + ";border-color:" + T.blue + ";color:" + T.blue + "}"
    "QLineEdit,QSpinBox,QDoubleSpinBox,QComboBox{background:" + T.bg + ";color:" + T.text
    + ";border:1px solid " + T.border
    + ";border-radius:4px;padding:4px 8px;font-size:11px}"
    "QLineEdit:focus,QSpinBox:focus{border-color:" + T.blue + "}"
    "QComboBox::drop-down{border:none;padding-right:8px}"
    "QComboBox QAbstractItemView{background:" + T.surface + ";color:" + T.text
    + ";border:1px solid " + T.border
    + ";selection-background-color:" + T.blue + "}"
    "QPlainTextEdit,QTextEdit{background:" + T.bg
    + ";color:#c8c8dc;border:none;font-family:Consolas;font-size:12px}"
    "QLabel{color:" + T.text + "}"
    "QScrollBar:vertical{background:" + T.bg + ";width:8px}"
    "QScrollBar::handle:vertical{background:" + T.border
    + ";min-height:30px;border-radius:4px}"
    "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0}"
    "QScrollBar:horizontal{background:" + T.bg + ";height:8px}"
    "QScrollBar::handle:horizontal{background:" + T.border
    + ";min-width:30px;border-radius:4px}"
    "QScrollBar::add-line:horizontal,QScrollBar::sub-line:horizontal{width:0}"
    "QListWidget{background:" + T.bg + ";color:" + T.text
    + ";border:1px solid " + T.border
    + ";border-radius:4px;font-size:11px;outline:none}"
    "QListWidget::item{padding:4px 8px}"
    "QListWidget::item:selected{background:" + T.blueDim + ";color:" + T.blue + "}"
    "QListWidget::item:hover{background:" + T.surfHov + "}"
    "QCheckBox{color:" + T.textSec + ";spacing:6px}"
    "QCheckBox::indicator{width:14px;height:14px;border:1px solid " + T.border
    + ";border-radius:3px;background:" + T.bg + "}"
    "QCheckBox::indicator:checked{background:" + T.blue
    + ";border-color:" + T.blue + "}"
    "QSlider::groove:horizontal{background:" + T.border
    + ";height:4px;border-radius:2px}"
    "QSlider::handle:horizontal{background:" + T.blue
    + ";width:14px;height:14px;margin:-5px 0;border-radius:7px}"
    "QSlider::sub-page:horizontal{background:" + T.blue + ";border-radius:2px}"
)


# ═══════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════
def _lbl(text, color=None):
    lbl = QLabel(text)
    lbl.setFont(QFont(T.MONO, 9, QFont.Bold))
    lbl.setStyleSheet(
        "color:" + (color or T.textMut) + ";letter-spacing:1.5px;margin-top:4px"
    )
    return lbl


def make_field(label, widget, lay):
    lay.addWidget(_lbl(label))
    lay.addWidget(widget)
    return widget


def make_spin(val, lo, hi, lay, label):
    s = QSpinBox()
    s.setRange(lo, hi)
    s.setValue(val)
    s.setFont(QFont(T.MONO, 11))
    return make_field(label, s, lay)


def make_combo(items, cur, lay, label):
    c = QComboBox()
    c.addItems(items)
    if cur in items:
        c.setCurrentText(cur)
    c.setFont(QFont(T.MONO, 11))
    return make_field(label, c, lay)


def make_line(text, lay, label, mono=False):
    e = QLineEdit(text)
    e.setFont(QFont(T.MONO if mono else T.UI, 11))
    return make_field(label, e, lay)


def _sep_h():
    f = QFrame()
    f.setFrameShape(QFrame.HLine)
    f.setStyleSheet("color:" + T.border)
    return f


# ═══════════════════════════════════════════════════════════════
#  UNDO STACK
# ═══════════════════════════════════════════════════════════════
class UndoStack:
    def __init__(self, max_size=50):
        self._stack = []
        self._idx = -1
        self._max = max_size

    def push(self, state):
        self._stack = self._stack[: self._idx + 1]
        self._stack.append(copy.deepcopy(state))
        if len(self._stack) > self._max:
            self._stack.pop(0)
        self._idx = len(self._stack) - 1

    def undo(self):
        if self._idx > 0:
            self._idx -= 1
            return copy.deepcopy(self._stack[self._idx])
        return None

    def redo(self):
        if self._idx < len(self._stack) - 1:
            self._idx += 1
            return copy.deepcopy(self._stack[self._idx])
        return None

    def can_undo(self):
        return self._idx > 0

    def can_redo(self):
        return self._idx < len(self._stack) - 1


# ═══════════════════════════════════════════════════════════════
#  VISUAL CANVAS — Advanced with pan, zoom, drag
# ═══════════════════════════════════════════════════════════════
class VisualCanvas(QWidget):
    pinPlaced = pyqtSignal(int, int)
    ledPlaced = pyqtSignal(int, int)
    displayDrawn = pyqtSignal(int, int, int, int)
    itemClicked = pyqtSignal(str, int)
    itemMoved = pyqtSignal(str, int, int, int)
    mouseAt = pyqtSignal(int, int)

    def __init__(self, main_win):
        super().__init__()
        self.mw = main_win
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.tool = "select"
        self.zoom = 2.0
        self.pan = QPointF(0, 0)
        self.image = None
        self.image_path = None
        self.img_opacity = 1.0

        # Interaction state
        self._drag_item = None   # ("pin",idx) or ("led",idx)
        self._drag_offset = None
        self._disp_start = None
        self._disp_end = None
        self._panning = False
        self._pan_start = None
        self._pan_start_cam = None
        self._space_held = False

        self.grid_snap = True
        self.grid_size = 8
        self.show_grid = True

    def set_image(self, img, path):
        self.image = img
        self.image_path = path
        self.update()

    def clear_image(self):
        self.image = None
        self.image_path = None
        self.update()

    def snap(self, v):
        if self.grid_snap:
            return round(v / self.grid_size) * self.grid_size
        return v

    def _to_dev(self, widget_pos):
        """Convert widget coords to device coords."""
        x = (widget_pos.x() - self.pan.x()) / self.zoom
        y = (widget_pos.y() - self.pan.y()) / self.zoom
        return x, y

    def _from_dev(self, dx, dy):
        """Convert device coords to widget coords."""
        return QPointF(dx * self.zoom + self.pan.x(), dy * self.zoom + self.pan.y())

    def _find_item_at(self, dx, dy):
        """Find pin or LED near device coords. Returns (type, index) or None."""
        mw = self.mw
        # Check LEDs first (they're usually on top)
        for i, led in enumerate(mw.leds):
            r = led.get("radius", 8) + 3
            if math.hypot(dx - led["x"], dy - led["y"]) < r:
                return ("led", i)
        for i, pin in enumerate(mw.pins):
            if math.hypot(dx - pin["x"], dy - pin["y"]) < 8:
                return ("pin", i)
        return None

    # ── Mouse events ──
    def mousePressEvent(self, e):
        dx, dy = self._to_dev(e.pos())
        mw = self.mw

        # Middle button or Space+left = pan
        if e.button() == Qt.MiddleButton or (
            e.button() == Qt.LeftButton and self._space_held
        ):
            self._panning = True
            self._pan_start = e.pos()
            self._pan_start_cam = QPointF(self.pan)
            self.setCursor(Qt.ClosedHandCursor)
            return

        if e.button() == Qt.RightButton:
            self._show_context_menu(e.pos(), dx, dy)
            return

        if e.button() != Qt.LeftButton:
            return

        if self.tool == "pin":
            sx, sy = self.snap(dx), self.snap(dy)
            self.pinPlaced.emit(int(sx), int(sy))
        elif self.tool == "led":
            sx, sy = self.snap(dx), self.snap(dy)
            self.ledPlaced.emit(int(sx), int(sy))
        elif self.tool == "display":
            self._disp_start = (dx, dy)
            self._disp_end = None
        elif self.tool == "select":
            hit = self._find_item_at(dx, dy)
            if hit:
                typ, idx = hit
                self.itemClicked.emit(typ, idx)
                # Begin drag
                if typ == "pin" and 0 <= idx < len(mw.pins):
                    p = mw.pins[idx]
                    self._drag_item = ("pin", idx)
                    self._drag_offset = (dx - p["x"], dy - p["y"])
                elif typ == "led" and 0 <= idx < len(mw.leds):
                    led = mw.leds[idx]
                    self._drag_item = ("led", idx)
                    self._drag_offset = (dx - led["x"], dy - led["y"])
            else:
                self.itemClicked.emit("none", -1)

    def mouseMoveEvent(self, e):
        dx, dy = self._to_dev(e.pos())
        self.mouseAt.emit(int(dx), int(dy))

        if self._panning and self._pan_start:
            delta = e.pos() - self._pan_start
            self.pan = self._pan_start_cam + QPointF(delta.x(), delta.y())
            self.update()
            return

        if self._disp_start:
            self._disp_end = (dx, dy)
            self.update()
            return

        if self._drag_item and self._drag_offset:
            ox, oy = self._drag_offset
            nx = self.snap(dx - ox)
            ny = self.snap(dy - oy)
            typ, idx = self._drag_item
            mw = self.mw
            if typ == "pin" and 0 <= idx < len(mw.pins):
                mw.pins[idx]["x"] = int(nx)
                mw.pins[idx]["y"] = int(ny)
            elif typ == "led" and 0 <= idx < len(mw.leds):
                mw.leds[idx]["x"] = int(nx)
                mw.leds[idx]["y"] = int(ny)
            self.update()
            return

        # Update cursor
        if self.tool in ("pin", "led"):
            self.setCursor(Qt.CrossCursor)
        elif self.tool == "display":
            self.setCursor(Qt.CrossCursor)
        else:
            hit = self._find_item_at(dx, dy)
            self.setCursor(Qt.SizeAllCursor if hit else Qt.ArrowCursor)

        self.update()

    def mouseReleaseEvent(self, e):
        if self._panning:
            self._panning = False
            self.setCursor(Qt.ArrowCursor)
            return

        if self._drag_item:
            typ, idx = self._drag_item
            mw = self.mw
            if typ == "pin" and 0 <= idx < len(mw.pins):
                p = mw.pins[idx]
                self.itemMoved.emit(typ, idx, p["x"], p["y"])
            elif typ == "led" and 0 <= idx < len(mw.leds):
                led = mw.leds[idx]
                self.itemMoved.emit(typ, idx, led["x"], led["y"])
            self._drag_item = None
            self._drag_offset = None
            self.update()
            return

        if self.tool == "display" and self._disp_start:
            if self._disp_end:
                x0, y0 = self._disp_start
                x1, y1 = self._disp_end
                rx, ry = min(x0, x1), min(y0, y1)
                rw, rh = abs(x1 - x0), abs(y1 - y0)
                if rw > 4 and rh > 4:
                    self.displayDrawn.emit(int(rx), int(ry), int(rw), int(rh))
            self._disp_start = None
            self._disp_end = None
            self.update()

    def wheelEvent(self, e):
        # Zoom toward cursor
        old_zoom = self.zoom
        factor = 1.15 if e.angleDelta().y() > 0 else 1 / 1.15
        new_zoom = max(0.5, min(8.0, self.zoom * factor))
        # Adjust pan so mouse position stays fixed
        mx, my = e.pos().x(), e.pos().y()
        self.pan = QPointF(
            mx - (mx - self.pan.x()) * new_zoom / old_zoom,
            my - (my - self.pan.y()) * new_zoom / old_zoom,
        )
        self.zoom = new_zoom
        self.update()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Space:
            self._space_held = True
            self.setCursor(Qt.OpenHandCursor)
        elif e.key() == Qt.Key_G:
            self.grid_snap = not self.grid_snap
            self.mw._update_grid_btn()
            self.update()
        elif e.key() in (Qt.Key_Delete, Qt.Key_Backspace):
            self.mw._delete_selected()
        elif e.key() == Qt.Key_Escape:
            self.mw._deselect()
            self.tool = "select"
            self.mw._sync_tool_btns()
        else:
            e.ignore()

    def keyReleaseEvent(self, e):
        if e.key() == Qt.Key_Space:
            self._space_held = False
            self.setCursor(Qt.ArrowCursor)

    def _show_context_menu(self, pos, dx, dy):
        hit = self._find_item_at(dx, dy)
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu{background:" + T.surface + ";color:" + T.text
            + ";border:1px solid " + T.border + ";border-radius:4px;padding:4px}"
            "QMenu::item{padding:6px 20px}"
            "QMenu::item:selected{background:" + T.blue + ";color:#000}"
        )
        if hit:
            typ, idx = hit
            self.itemClicked.emit(typ, idx)
            name = "Pin" if typ == "pin" else "LED"
            menu.addAction(f"Select {name}", lambda: self.itemClicked.emit(typ, idx))
            menu.addAction(
                f"Duplicate {name}",
                lambda: self.mw._duplicate_item(typ, idx),
            )
            menu.addSeparator()
            a_del = menu.addAction(f"Delete {name}")
            a_del.triggered.connect(lambda: self.mw._delete_item(typ, idx))
        else:
            menu.addAction(
                "Place Pin here",
                lambda: self.pinPlaced.emit(int(self.snap(dx)), int(self.snap(dy))),
            )
            menu.addAction(
                "Place LED here",
                lambda: self.ledPlaced.emit(int(self.snap(dx)), int(self.snap(dy))),
            )
            menu.addSeparator()
            snap_act = menu.addAction(
                "Grid Snap: ON" if self.grid_snap else "Grid Snap: OFF"
            )
            snap_act.triggered.connect(lambda: self._toggle_snap())
            menu.addAction(
                "Reset View", lambda: self._reset_view()
            )
        menu.exec_(self.mapToGlobal(pos))

    def _toggle_snap(self):
        self.grid_snap = not self.grid_snap
        self.mw._update_grid_btn()
        self.update()

    def _reset_view(self):
        self.zoom = 2.0
        self.pan = QPointF(
            self.width() / 2 - self.mw.dev_w.value(),
            self.height() / 2 - self.mw.dev_h.value(),
        )
        self.update()

    def center_view(self):
        dw = self.mw.dev_w.value()
        dh = self.mw.dev_h.value()
        self.pan = QPointF(
            (self.width() - dw * self.zoom) / 2,
            (self.height() - dh * self.zoom) / 2,
        )
        self.update()

    # ── Paint ──
    def paintEvent(self, event):
        mw = self.mw
        dw = mw.dev_w.value()
        dh = mw.dev_h.value()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)

        # Background
        p.fillRect(self.rect(), QColor("#08080a"))

        p.save()
        p.translate(self.pan)
        p.scale(self.zoom, self.zoom)

        # Grid
        if self.show_grid:
            gs = self.grid_size
            p.setPen(QPen(QColor("#ffffff08"), 0.5))
            for gx in range(0, dw + 1, gs):
                p.drawLine(QPointF(gx, 0), QPointF(gx, dh))
            for gy in range(0, dh + 1, gs):
                p.drawLine(QPointF(0, gy), QPointF(dw, gy))

        # Device boundary
        p.setPen(QPen(QColor(T.border), 1, Qt.DashLine))
        p.setBrush(Qt.NoBrush)
        p.drawRect(QRectF(-0.5, -0.5, dw + 1, dh + 1))

        # Device image
        if self.image and not self.image.isNull():
            p.setOpacity(self.img_opacity)
            p.drawImage(QRectF(0, 0, dw, dh), self.image)
            p.setOpacity(1.0)
        else:
            p.fillRect(0, 0, dw, dh, QColor(mw.dev_color.text()))
            p.setPen(QColor(T.textMut))
            p.setFont(QFont(T.MONO, 10))
            p.drawText(QRectF(0, 0, dw, dh), Qt.AlignCenter, "No image\nUpload one")

        # Display region
        if mw.has_display.isChecked():
            dr = mw.disp_region
            p.fillRect(
                QRectF(dr["x"], dr["y"], dr["w"], dr["h"]),
                QColor(mw.disp_bg.text()),
            )
            p.setPen(QPen(QColor(T.blue), 1, Qt.DashLine))
            p.setBrush(Qt.NoBrush)
            p.drawRect(QRectF(dr["x"], dr["y"], dr["w"], dr["h"]))
            p.setPen(QColor(T.blue + "aa"))
            p.setFont(QFont(T.MONO, 7))
            p.drawText(
                QRectF(dr["x"], dr["y"], dr["w"], dr["h"]),
                Qt.AlignCenter,
                f"{mw.disp_px_w.value()}x{mw.disp_px_h.value()}",
            )

        # Region drag preview
        if self._disp_start and self._disp_end:
            x0, y0 = self._disp_start
            x1, y1 = self._disp_end
            p.setPen(QPen(QColor(T.blue), 1.5, Qt.DashLine))
            p.setBrush(QBrush(QColor(74, 158, 255, 30)))
            p.drawRect(
                QRectF(min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0))
            )

        # LEDs
        test_state = mw.test_state if mw.test_running else {}
        for i, led in enumerate(mw.leds):
            sv = led.get("state_var", "")
            ov = led.get("on_value", True)
            is_on = mw.test_running and test_state.get(sv) == ov
            lx, ly = led["x"], led["y"]
            lr = led.get("radius", 8)
            lc = QColor(led.get("color", "#ff3344"))
            is_sel = mw.sel_type == "led" and mw.sel_idx == i

            if is_on:
                grad = QRadialGradient(lx, ly, lr * 3)
                grad.setColorAt(0, QColor(lc.red(), lc.green(), lc.blue(), 200))
                grad.setColorAt(1, QColor(lc.red(), lc.green(), lc.blue(), 0))
                p.setBrush(QBrush(grad))
                p.setPen(Qt.NoPen)
                p.drawEllipse(QPointF(lx, ly), lr * 3, lr * 3)

            fill = (
                QColor(lc)
                if is_on
                else QColor(lc.red() // 4, lc.green() // 4, lc.blue() // 4, 120)
            )
            p.setBrush(QBrush(fill))
            if is_sel:
                p.setPen(QPen(QColor(T.orange), 2.5))
            else:
                p.setPen(QPen(QColor(lc.red() // 2, lc.green() // 2, lc.blue() // 2), 1))
            p.drawEllipse(QPointF(lx, ly), lr, lr)

            # Selection box
            if is_sel:
                p.setPen(QPen(QColor(T.orange), 1, Qt.DashLine))
                p.setBrush(Qt.NoBrush)
                p.drawRect(QRectF(lx - lr - 4, ly - lr - 4, lr * 2 + 8, lr * 2 + 8))

            p.setPen(QColor(T.text))
            p.setFont(QFont(T.MONO, 6, QFont.Bold))
            p.drawText(QPointF(lx - 10, ly - lr - 4), led.get("label", "?"))

        # Pins
        mouse_dx, mouse_dy = self._to_dev(self.mapFromGlobal(QCursor.pos()))
        for i, pin in enumerate(mw.pins):
            pc = QColor(PIN_CLR.get(pin.get("type", "digital"), "#808090"))
            is_sel = mw.sel_type == "pin" and mw.sel_idx == i
            dist = math.hypot(mouse_dx - pin["x"], mouse_dy - pin["y"])
            is_hov = dist < 8 and self.underMouse()
            r = 7 if is_sel else 6 if is_hov else 4

            if is_sel:
                p.setBrush(QBrush(QColor("#ffffff")))
                p.setPen(QPen(QColor(T.orange), 2.5))
            elif is_hov:
                p.setBrush(QBrush(QColor(T.blue)))
                p.setPen(QPen(QColor(T.blue + "88"), 1.5))
            else:
                p.setBrush(QBrush(pc))
                p.setPen(QPen(QColor(pc.red(), pc.green(), pc.blue(), 60), 1))
            p.drawEllipse(QPointF(pin["x"], pin["y"]), r, r)

            # Selection box
            if is_sel:
                p.setPen(QPen(QColor(T.orange), 1, Qt.DashLine))
                p.setBrush(Qt.NoBrush)
                p.drawRect(QRectF(pin["x"] - 10, pin["y"] - 10, 20, 20))

            # Direction stub
            dirs = {
                "left": (-1, 0), "right": (1, 0),
                "top": (0, -1), "bottom": (0, 1),
            }
            ddx, ddy = dirs.get(pin.get("side", "left"), (0, 0))
            stub_c = QColor(pc.red(), pc.green(), pc.blue(), 120)
            p.setPen(QPen(stub_c, 1.5))
            p.drawLine(
                QPointF(pin["x"], pin["y"]),
                QPointF(pin["x"] + ddx * 12, pin["y"] + ddy * 12),
            )

            # Label
            p.setPen(QColor(T.text))
            p.setFont(QFont(T.MONO, 6, QFont.Bold))
            p.drawText(QPointF(pin["x"] - 10, pin["y"] - 10), pin.get("label", "?"))

            # Hover tooltip
            if is_hov and not self._drag_item:
                txt = f'{pin.get("label", "?")} ({pin.get("type", "?")})'
                p.setFont(QFont(T.MONO, 7, QFont.Bold))
                fm = p.fontMetrics()
                tw = fm.horizontalAdvance(txt) + 14
                p.setBrush(QBrush(QColor(0, 0, 0, 230)))
                p.setPen(Qt.NoPen)
                p.drawRoundedRect(
                    QRectF(pin["x"] - tw / 2, pin["y"] - 30, tw, 18), 4, 4
                )
                p.setPen(QColor("#ffffff"))
                p.drawText(
                    QRectF(pin["x"] - tw / 2, pin["y"] - 30, tw, 18),
                    Qt.AlignCenter, txt,
                )

        # Snap crosshair when placing
        if self.tool in ("pin", "led") and self.underMouse():
            sx, sy = self.snap(mouse_dx), self.snap(mouse_dy)
            p.setPen(QPen(QColor(T.orange + "66"), 0.8, Qt.DashLine))
            p.drawLine(QPointF(sx, 0), QPointF(sx, dh))
            p.drawLine(QPointF(0, sy), QPointF(dw, sy))
            # Ghost dot
            p.setBrush(QBrush(QColor(T.orange + "44")))
            p.setPen(QPen(QColor(T.orange), 1.5, Qt.DashLine))
            p.drawEllipse(QPointF(sx, sy), 6, 6)

        p.restore()

        # Zoom indicator
        p.setPen(QColor(T.textMut))
        p.setFont(QFont(T.MONO, 9))
        p.drawText(8, self.height() - 8, f"{self.zoom:.1f}x")

        p.end()


# ═══════════════════════════════════════════════════════════════
#  DEFAULT EMULATION TEMPLATE
# ═══════════════════════════════════════════════════════════════
DEFAULT_EMU = """{
  "type": "active",
  "state_vars": {
    "led_on": false,
    "brightness": 0
  },
  "rules": [
    {
      "trigger": "pin_high",
      "pin": "anode",
      "action": "set_state",
      "target": "led_on",
      "value": true
    },
    {
      "trigger": "pin_low",
      "pin": "anode",
      "action": "set_state",
      "target": "led_on",
      "value": false
    }
  ],
  "properties": {
    "forward_voltage": 2.0,
    "max_current_ma": 20
  }
}"""


# ═══════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ═══════════════════════════════════════════════════════════════
class DeviceCreator(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Asteron Workbench \u2014 Device Creator")
        self.setMinimumSize(1050, 680)
        self.resize(1380, 850)
        self.setStyleSheet(SS)

        self.pins = []
        self.leds = []
        self.disp_region = {"x": 10, "y": 10, "w": 80, "h": 40}
        self.image_b64 = None
        self.sel_type = "none"
        self.sel_idx = -1
        self.test_running = False
        self.test_state = {}
        self.test_tick = 0
        self.undo = UndoStack()

        self.test_timer = QTimer()
        self.test_timer.setInterval(500)
        self.test_timer.timeout.connect(self._test_tick)

        self._build_ui()
        self.st_msg = QLabel("Ready")
        self.st_msg.setFont(QFont(T.MONO, 10))
        self.st_coord = QLabel("(0, 0)")
        self.st_coord.setFont(QFont(T.MONO, 10))
        self.st_coord.setStyleSheet("color:" + T.textMut)
        sb = self.statusBar()
        sb.addWidget(self.st_msg, 1)
        sb.addPermanentWidget(self.st_coord)

        self._save_undo()

    def _save_undo(self):
        self.undo.push({
            "pins": copy.deepcopy(self.pins),
            "leds": copy.deepcopy(self.leds),
        })

    def _do_undo(self):
        state = self.undo.undo()
        if state:
            self.pins = state["pins"]
            self.leds = state["leds"]
            self._deselect()
            self._refresh_lists()
            self.canvas.update()

    def _do_redo(self):
        state = self.undo.redo()
        if state:
            self.pins = state["pins"]
            self.leds = state["leds"]
            self._deselect()
            self._refresh_lists()
            self.canvas.update()

    # ─────────────────────────────────────────────────────────
    # UI
    # ─────────────────────────────────────────────────────────
    def _build_ui(self):
        cw = QWidget()
        self.setCentralWidget(cw)
        ml = QVBoxLayout(cw)
        ml.setContentsMargins(0, 0, 0, 0)
        ml.setSpacing(0)

        # Top bar
        bar = QWidget()
        bar.setFixedHeight(46)
        bar.setStyleSheet(
            "background:" + T.panel + ";border-bottom:1px solid " + T.border
        )
        tb = QHBoxLayout(bar)
        tb.setContentsMargins(14, 0, 14, 0)
        tb.setSpacing(8)

        logo = QLabel("ASTERON")
        logo.setFont(QFont(T.MONO, 15, QFont.Bold))
        logo.setStyleSheet("color:" + T.blue + ";letter-spacing:3px")
        tb.addWidget(logo)
        sub = QLabel("Workbench \u2022 Device Creator")
        sub.setFont(QFont(T.MONO, 10))
        sub.setStyleSheet("color:" + T.textMut)
        tb.addWidget(sub)
        tb.addSpacing(20)

        btn_imp = QPushButton("Import .adev")
        btn_imp.clicked.connect(self._import_adev)
        tb.addWidget(btn_imp)
        tb.addStretch()

        btn_undo = QPushButton("Undo")
        btn_undo.clicked.connect(self._do_undo)
        btn_undo.setToolTip("Ctrl+Z")
        tb.addWidget(btn_undo)
        btn_redo = QPushButton("Redo")
        btn_redo.clicked.connect(self._do_redo)
        btn_redo.setToolTip("Ctrl+Shift+Z")
        tb.addWidget(btn_redo)

        tb.addSpacing(10)
        btn_exp = QPushButton("Export .adev")
        btn_exp.setStyleSheet(
            "QPushButton{background:" + T.blueDim + ";color:" + T.blue
            + ";border:1px solid " + T.blue + "55;border-radius:4px;"
            "padding:7px 22px;font-weight:bold}"
            "QPushButton:hover{background:" + T.blue + ";color:#000}"
        )
        btn_exp.clicked.connect(self._export)
        tb.addWidget(btn_exp)
        ml.addWidget(bar)

        self.tabs = QTabWidget()
        ml.addWidget(self.tabs)
        self._build_info_tab()
        self._build_visual_tab()
        self._build_emu_tab()
        self._build_preview_tab()
        self._build_export_tab()

    # ── INFO TAB ──
    def _build_info_tab(self):
        outer = QScrollArea()
        outer.setWidgetResizable(True)
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(4)
        lay.setAlignment(Qt.AlignTop)

        hdr = QLabel("Device Information")
        hdr.setFont(QFont(T.UI, 18, QFont.Bold))
        lay.addWidget(hdr)
        lay.addSpacing(10)

        self.dev_id = make_line("my_device", lay, "DEVICE ID", mono=True)
        self.dev_name = make_line("My Device", lay, "NAME")
        self.dev_category = make_combo(CATEGORIES, "Output", lay, "CATEGORY")

        lay.addWidget(_lbl("DESCRIPTION"))
        self.dev_desc = QPlainTextEdit()
        self.dev_desc.setMaximumHeight(70)
        self.dev_desc.setFont(QFont(T.UI, 11))
        lay.addWidget(self.dev_desc)

        row = QHBoxLayout()
        v1 = QVBoxLayout()
        self.dev_author = make_line("", v1, "AUTHOR")
        row.addLayout(v1)
        v2 = QVBoxLayout()
        self.dev_version = make_line("1.0", v2, "VERSION", mono=True)
        row.addLayout(v2)
        lay.addLayout(row)

        row2 = QHBoxLayout()
        v3 = QVBoxLayout()
        self.dev_w = make_spin(100, 10, 2000, v3, "CANVAS WIDTH")
        row2.addLayout(v3)
        v4 = QVBoxLayout()
        self.dev_h = make_spin(100, 10, 2000, v4, "CANVAS HEIGHT")
        row2.addLayout(v4)
        lay.addLayout(row2)
        self.dev_w.valueChanged.connect(self._on_dims_changed)
        self.dev_h.valueChanged.connect(self._on_dims_changed)

        row3 = QHBoxLayout()
        v5 = QVBoxLayout()
        self.dev_label = make_line("DEV", v5, "LABEL", mono=True)
        row3.addLayout(v5)
        v6 = QVBoxLayout()
        v6.addWidget(_lbl("COLOR"))
        cr = QHBoxLayout()
        self.color_btn = QPushButton("  ")
        self.color_btn.setFixedSize(30, 30)
        self.color_btn.setStyleSheet(
            "background:#555;border:1px solid " + T.border + ";border-radius:4px"
        )
        self.color_btn.clicked.connect(self._pick_color)
        cr.addWidget(self.color_btn)
        self.dev_color = QLineEdit("#555555")
        self.dev_color.setFont(QFont(T.MONO, 11))
        self.dev_color.textChanged.connect(self._on_color_changed)
        cr.addWidget(self.dev_color)
        v6.addLayout(cr)
        row3.addLayout(v6)
        lay.addLayout(row3)
        lay.addStretch()

        outer.setWidget(w)
        self.tabs.addTab(outer, "Info")

    def _on_color_changed(self, t):
        if QColor(t).isValid():
            self.color_btn.setStyleSheet(
                "background:" + t + ";border:1px solid " + T.border + ";border-radius:4px"
            )

    def _pick_color(self):
        c = QColorDialog.getColor(QColor(self.dev_color.text()), self)
        if c.isValid():
            self.dev_color.setText(c.name())

    def _on_dims_changed(self):
        self._refresh_info()
        if hasattr(self, "canvas"):
            self.canvas.update()
        if hasattr(self, "preview_canvas"):
            self.preview_canvas.update()

    # ── VISUAL TAB ──
    def _build_visual_tab(self):
        w = QWidget()
        layout = QHBoxLayout(w)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # LEFT: canvas
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(0)

        # Toolbar
        ctb_w = QWidget()
        ctb_w.setFixedHeight(40)
        ctb_w.setStyleSheet(
            "background:" + T.panelAlt + ";border-bottom:1px solid " + T.border
        )
        ctb = QHBoxLayout(ctb_w)
        ctb.setContentsMargins(8, 0, 8, 0)
        ctb.setSpacing(4)

        # Tool buttons
        self.vtool_btns = {}
        tools = [
            ("select", "Select"),
            ("pin", "Pin"),
            ("led", "LED"),
            ("display", "Display"),
        ]
        for tid, label in tools:
            b = QPushButton(label)
            b.setCheckable(True)
            b.setChecked(tid == "select")
            b.setFont(QFont(T.MONO, 10, QFont.Bold))
            b.clicked.connect(lambda _, t=tid: self._set_vtool(t))
            ctb.addWidget(b)
            self.vtool_btns[tid] = b

        ctb.addWidget(self._vsep())

        # Grid snap button
        self.grid_btn = QPushButton("Grid: ON")
        self.grid_btn.setCheckable(True)
        self.grid_btn.setChecked(True)
        self.grid_btn.setFont(QFont(T.MONO, 9))
        self.grid_btn.setToolTip("Toggle grid snap (G)")
        self.grid_btn.clicked.connect(self._toggle_grid)
        ctb.addWidget(self.grid_btn)

        ctb.addWidget(self._vsep())

        # Image controls
        btn_img = QPushButton("Upload Image")
        btn_img.clicked.connect(self._upload_image)
        ctb.addWidget(btn_img)
        btn_rm = QPushButton("Remove")
        btn_rm.setStyleSheet("QPushButton{color:" + T.red + "}")
        btn_rm.clicked.connect(self._remove_image)
        ctb.addWidget(btn_rm)

        ctb.addWidget(self._vsep())

        # Image opacity
        op_lbl = QLabel("Opacity:")
        op_lbl.setFont(QFont(T.MONO, 9))
        op_lbl.setStyleSheet("color:" + T.textMut)
        ctb.addWidget(op_lbl)
        self.opacity_slider = QSlider(Qt.Horizontal)
        self.opacity_slider.setRange(10, 100)
        self.opacity_slider.setValue(100)
        self.opacity_slider.setFixedWidth(80)
        self.opacity_slider.valueChanged.connect(self._on_opacity)
        ctb.addWidget(self.opacity_slider)

        ctb.addWidget(self._vsep())

        # Fit image button
        btn_fit = QPushButton("Fit Image")
        btn_fit.setToolTip("Resize canvas to match image")
        btn_fit.clicked.connect(self._fit_image)
        ctb.addWidget(btn_fit)

        ctb.addStretch()
        self.vis_info = QLabel("100x100 | 0 pins | 0 LEDs")
        self.vis_info.setFont(QFont(T.MONO, 9))
        self.vis_info.setStyleSheet("color:" + T.textMut)
        ctb.addWidget(self.vis_info)
        ll.addWidget(ctb_w)

        # Canvas
        self.canvas = VisualCanvas(self)
        self.canvas.pinPlaced.connect(self._on_pin_placed)
        self.canvas.ledPlaced.connect(self._on_led_placed)
        self.canvas.displayDrawn.connect(self._on_display_drawn)
        self.canvas.itemClicked.connect(self._on_item_clicked)
        self.canvas.itemMoved.connect(self._on_item_moved)
        self.canvas.mouseAt.connect(self._on_mouse_at)
        ll.addWidget(self.canvas)
        layout.addWidget(left, 1)

        # RIGHT: properties
        right = QWidget()
        right.setFixedWidth(290)
        right.setStyleSheet(
            "background:" + T.panel + ";border-left:1px solid " + T.border
        )
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        self.prop_stack = QStackedWidget()
        rl.addWidget(self.prop_stack)
        self._build_overview_page()
        self._build_pin_editor_page()
        self._build_led_editor_page()
        self.prop_stack.setCurrentIndex(0)
        layout.addWidget(right)

        self.tabs.addTab(w, "Visual")

    def _vsep(self):
        f = QFrame()
        f.setFrameShape(QFrame.VLine)
        f.setStyleSheet("color:" + T.border)
        return f

    def _build_overview_page(self):
        page = QScrollArea()
        page.setWidgetResizable(True)
        inner = QWidget()
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(4)

        lay.addWidget(_lbl("PINS"))
        self.pin_list = QListWidget()
        self.pin_list.setMaximumHeight(160)
        self.pin_list.itemClicked.connect(
            lambda: self._on_item_clicked("pin", self.pin_list.currentRow())
        )
        lay.addWidget(self.pin_list)

        # Auto-layout buttons
        al = QHBoxLayout()
        al.setSpacing(4)
        for side, label in [("left", "L"), ("right", "R"), ("top", "T"), ("bottom", "B")]:
            b = QPushButton(label)
            b.setFixedWidth(32)
            b.setToolTip(f"Distribute pins along {side} edge")
            b.clicked.connect(lambda _, s=side: self._auto_layout_pins(s))
            al.addWidget(b)
        al_lbl = QLabel("Auto-layout:")
        al_lbl.setFont(QFont(T.MONO, 8))
        al_lbl.setStyleSheet("color:" + T.textMut)
        al.addWidget(al_lbl)
        al.addStretch()
        lay.addLayout(al)

        lay.addWidget(_sep_h())
        lay.addWidget(_lbl("LED INDICATORS"))
        self.led_list = QListWidget()
        self.led_list.setMaximumHeight(100)
        self.led_list.itemClicked.connect(
            lambda: self._on_item_clicked("led", self.led_list.currentRow())
        )
        lay.addWidget(self.led_list)

        lay.addWidget(_sep_h())
        lay.addWidget(_lbl("DISPLAY REGION"))
        self.has_display = QCheckBox("Has display region")
        self.has_display.toggled.connect(lambda _: self.canvas.update())
        lay.addWidget(self.has_display)

        dg = QWidget()
        dl = QVBoxLayout(dg)
        dl.setContentsMargins(0, 4, 0, 0)
        dl.setSpacing(4)
        self.disp_type = make_line("oled_ssd1306", dl, "TYPE", mono=True)
        r1 = QHBoxLayout()
        v1 = QVBoxLayout()
        self.disp_px_w = make_spin(128, 1, 4096, v1, "PX W")
        r1.addLayout(v1)
        v2 = QVBoxLayout()
        self.disp_px_h = make_spin(64, 1, 4096, v2, "PX H")
        r1.addLayout(v2)
        dl.addLayout(r1)
        r2 = QHBoxLayout()
        v3 = QVBoxLayout()
        self.disp_color = make_line("#00aaff", v3, "PIXEL CLR", mono=True)
        r2.addLayout(v3)
        v4 = QVBoxLayout()
        self.disp_bg = make_line("#000510", v4, "BG CLR", mono=True)
        r2.addLayout(v4)
        dl.addLayout(r2)
        r3 = QHBoxLayout()
        v5 = QVBoxLayout()
        self.disp_iface = make_combo(["i2c", "spi", "parallel"], "i2c", v5, "INTERFACE")
        r3.addLayout(v5)
        v6 = QVBoxLayout()
        self.disp_addr = make_line("0x3C", v6, "ADDR", mono=True)
        r3.addLayout(v6)
        dl.addLayout(r3)
        lay.addWidget(dg)
        lay.addStretch()

        shortcuts = QLabel(
            "Shortcuts: G=snap  Del=delete  Space+drag=pan\n"
            "Scroll=zoom  Right-click=menu  Ctrl+Z=undo"
        )
        shortcuts.setFont(QFont(T.MONO, 8))
        shortcuts.setStyleSheet(
            "color:" + T.textMut + ";padding:8px;border-top:1px solid " + T.border
        )
        shortcuts.setWordWrap(True)
        lay.addWidget(shortcuts)

        page.setWidget(inner)
        self.prop_stack.addWidget(page)

    def _build_pin_editor_page(self):
        page = QScrollArea()
        page.setWidgetResizable(True)
        inner = QWidget()
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(4)

        hdr = QHBoxLayout()
        title = QLabel("Pin Properties")
        title.setFont(QFont(T.UI, 14, QFont.Bold))
        hdr.addWidget(title)
        btn_back = QPushButton("Back")
        btn_back.clicked.connect(self._deselect)
        hdr.addWidget(btn_back)
        lay.addLayout(hdr)

        self.pe_id = make_line("", lay, "ID", mono=True)
        self.pe_label = make_line("", lay, "LABEL", mono=True)
        r = QHBoxLayout()
        v1 = QVBoxLayout()
        self.pe_x = make_spin(0, -9999, 9999, v1, "X")
        r.addLayout(v1)
        v2 = QVBoxLayout()
        self.pe_y = make_spin(0, -9999, 9999, v2, "Y")
        r.addLayout(v2)
        lay.addLayout(r)
        self.pe_type = make_combo(PIN_TYPES, "digital", lay, "TYPE")
        self.pe_dir = make_combo(PIN_DIRS, "io", lay, "DIRECTION")
        self.pe_side = make_combo(PIN_SIDES, "left", lay, "SIDE")
        self.pe_notes = make_line("", lay, "NOTES")

        for w, f in [(self.pe_id, "id"), (self.pe_label, "label"), (self.pe_notes, "notes")]:
            w.textChanged.connect(lambda v, ff=f: self._upd_pin(ff, v))
        for w, f in [(self.pe_x, "x"), (self.pe_y, "y")]:
            w.valueChanged.connect(lambda v, ff=f: self._upd_pin(ff, v))
        for w, f in [(self.pe_type, "type"), (self.pe_dir, "direction"), (self.pe_side, "side")]:
            w.currentTextChanged.connect(lambda v, ff=f: self._upd_pin(ff, v))

        lay.addSpacing(10)
        lay.addWidget(_sep_h())
        btn_dup = QPushButton("Duplicate Pin")
        btn_dup.setStyleSheet("QPushButton{color:" + T.orange + "}")
        btn_dup.clicked.connect(lambda: self._duplicate_item("pin", self.sel_idx))
        lay.addWidget(btn_dup)
        btn_del = QPushButton("Delete Pin")
        btn_del.setStyleSheet("QPushButton{color:" + T.red + ";border-color:" + T.red + "44}")
        btn_del.clicked.connect(self._delete_selected)
        lay.addWidget(btn_del)
        lay.addStretch()

        page.setWidget(inner)
        self.prop_stack.addWidget(page)

    def _build_led_editor_page(self):
        page = QScrollArea()
        page.setWidgetResizable(True)
        inner = QWidget()
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(4)

        hdr = QHBoxLayout()
        title = QLabel("LED Indicator")
        title.setFont(QFont(T.UI, 14, QFont.Bold))
        hdr.addWidget(title)
        btn_back = QPushButton("Back")
        btn_back.clicked.connect(self._deselect)
        hdr.addWidget(btn_back)
        lay.addLayout(hdr)

        self.le_label = make_line("", lay, "LABEL", mono=True)
        r = QHBoxLayout()
        v1 = QVBoxLayout()
        self.le_x = make_spin(0, -9999, 9999, v1, "X")
        r.addLayout(v1)
        v2 = QVBoxLayout()
        self.le_y = make_spin(0, -9999, 9999, v2, "Y")
        r.addLayout(v2)
        lay.addLayout(r)
        self.le_radius = make_spin(8, 1, 100, lay, "RADIUS")

        lay.addWidget(_lbl("COLOR"))
        cr = QHBoxLayout()
        self.le_color_btn = QPushButton("  ")
        self.le_color_btn.setFixedSize(30, 30)
        self.le_color_btn.setStyleSheet(
            "background:#ff3344;border:1px solid " + T.border + ";border-radius:4px"
        )
        self.le_color_btn.clicked.connect(self._pick_led_color)
        cr.addWidget(self.le_color_btn)
        self.le_color = QLineEdit("#ff3344")
        self.le_color.setFont(QFont(T.MONO, 11))
        self.le_color.textChanged.connect(self._on_led_color_changed)
        cr.addWidget(self.le_color)
        lay.addLayout(cr)

        self.le_state_var = make_line("led_on", lay, "STATE VARIABLE", mono=True)
        self.le_on_value = make_line("true", lay, "ON VALUE", mono=True)

        for w, f in [(self.le_label, "label"), (self.le_color, "color"),
                     (self.le_state_var, "state_var"), (self.le_on_value, "on_value_str")]:
            w.textChanged.connect(lambda v, ff=f: self._upd_led(ff, v))
        for w, f in [(self.le_x, "x"), (self.le_y, "y"), (self.le_radius, "radius")]:
            w.valueChanged.connect(lambda v, ff=f: self._upd_led(ff, v))

        lay.addSpacing(10)
        lay.addWidget(_sep_h())
        btn_dup = QPushButton("Duplicate LED")
        btn_dup.setStyleSheet("QPushButton{color:" + T.orange + "}")
        btn_dup.clicked.connect(lambda: self._duplicate_item("led", self.sel_idx))
        lay.addWidget(btn_dup)
        btn_del = QPushButton("Delete LED")
        btn_del.setStyleSheet("QPushButton{color:" + T.red + ";border-color:" + T.red + "44}")
        btn_del.clicked.connect(self._delete_selected)
        lay.addWidget(btn_del)
        lay.addStretch()

        page.setWidget(inner)
        self.prop_stack.addWidget(page)

    def _on_led_color_changed(self, t):
        if QColor(t).isValid():
            self.le_color_btn.setStyleSheet(
                "background:" + t + ";border:1px solid " + T.border + ";border-radius:4px"
            )

    # ── EMULATION TAB ──
    def _build_emu_tab(self):
        w = QWidget()
        layout = QHBoxLayout(w)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(0)
        tbw = QWidget()
        tbw.setFixedHeight(34)
        tbw.setStyleSheet("background:" + T.panelAlt + ";border-bottom:1px solid " + T.border)
        tbl = QHBoxLayout(tbw)
        tbl.setContentsMargins(12, 0, 12, 0)
        tbl.addWidget(_lbl("emulation.json", T.textMut))
        tbl.addStretch()
        self.emu_status = QLabel("Valid JSON")
        self.emu_status.setFont(QFont(T.MONO, 10))
        self.emu_status.setStyleSheet("color:" + T.green)
        tbl.addWidget(self.emu_status)
        btn_fmt = QPushButton("Format")
        btn_fmt.clicked.connect(self._format_emu)
        tbl.addWidget(btn_fmt)
        ll.addWidget(tbw)
        self.emu_editor = QPlainTextEdit()
        self.emu_editor.setPlainText(DEFAULT_EMU)
        self.emu_editor.setFont(QFont(T.MONO, 12))
        self.emu_editor.textChanged.connect(self._validate_emu)
        ll.addWidget(self.emu_editor)
        layout.addWidget(left, 1)

        right = QWidget()
        right.setFixedWidth(230)
        right.setStyleSheet("background:" + T.panel + ";border-left:1px solid " + T.border)
        rl = QVBoxLayout(right)
        rl.setContentsMargins(10, 10, 10, 10)
        rl.setSpacing(6)
        triggers = ["pin_high", "pin_low", "pin_pwm", "analog_read", "user_press",
                     "user_release", "tone", "i2c_command", "display_print", "circuit_update"]
        actions = ["set_state", "compute", "return_value", "visual_update",
                   "render_text", "set_pixel", "clear_framebuffer"]
        for title, items in [("TRIGGERS", triggers), ("ACTIONS", actions)]:
            rl.addWidget(_lbl(title))
            lw = QListWidget()
            lw.setMaximumHeight(min(120, len(items) * 22))
            lw.setFont(QFont(T.MONO, 10))
            for item in items:
                lw.addItem(item)
            rl.addWidget(lw)
        rl.addWidget(_lbl("YOUR PINS"))
        self.emu_pin_list = QListWidget()
        self.emu_pin_list.setMaximumHeight(100)
        self.emu_pin_list.setFont(QFont(T.MONO, 10))
        rl.addWidget(self.emu_pin_list)
        rl.addStretch()
        layout.addWidget(right)
        self.tabs.addTab(w, "Emulation")

    def _validate_emu(self):
        try:
            json.loads(self.emu_editor.toPlainText())
            self.emu_status.setText("Valid JSON")
            self.emu_status.setStyleSheet("color:" + T.green)
            return True
        except json.JSONDecodeError as e:
            self.emu_status.setText("Error: " + str(e)[:35])
            self.emu_status.setStyleSheet("color:" + T.red)
            return False

    def _format_emu(self):
        try:
            obj = json.loads(self.emu_editor.toPlainText())
            self.emu_editor.setPlainText(json.dumps(obj, indent=2))
        except Exception:
            pass

    # ── PREVIEW TAB ──
    def _build_preview_tab(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        tbw = QWidget()
        tbw.setFixedHeight(38)
        tbw.setStyleSheet("background:" + T.panelAlt + ";border-bottom:1px solid " + T.border)
        tb = QHBoxLayout(tbw)
        tb.setContentsMargins(12, 0, 12, 0)
        tb.setSpacing(10)
        tb.addWidget(_lbl("Live Preview", T.textMut))
        self.btn_test = QPushButton("Run Test")
        self.btn_test.clicked.connect(self._toggle_test)
        tb.addWidget(self.btn_test)
        self.test_lbl = QLabel("")
        self.test_lbl.setFont(QFont(T.MONO, 10))
        self.test_lbl.setStyleSheet("color:" + T.green)
        tb.addWidget(self.test_lbl)
        tb.addStretch()
        layout.addWidget(tbw)

        self.preview_canvas = VisualCanvas(self)
        self.preview_canvas.tool = "select"
        self.preview_canvas.zoom = 3.0
        layout.addWidget(self.preview_canvas, 1)

        state_w = QWidget()
        state_w.setFixedHeight(70)
        state_w.setStyleSheet("background:" + T.panel + ";border-top:1px solid " + T.border)
        sl = QVBoxLayout(state_w)
        sl.setContentsMargins(12, 6, 12, 6)
        sl.addWidget(_lbl("STATE VARIABLES"))
        self.state_display = QLabel("No state")
        self.state_display.setFont(QFont(T.MONO, 10))
        self.state_display.setStyleSheet("color:" + T.textSec)
        self.state_display.setWordWrap(True)
        sl.addWidget(self.state_display)
        layout.addWidget(state_w)
        self.tabs.addTab(w, "Preview")

    def _toggle_test(self):
        if self.test_running:
            self.test_running = False
            self.test_state = {}
            self.test_timer.stop()
            self.btn_test.setText("Run Test")
            self.test_lbl.setText("")
            self.state_display.setText("Stopped")
        else:
            self.test_running = True
            self.test_tick = 0
            self.test_timer.start()
            self.btn_test.setText("Stop")
        self.canvas.update()
        self.preview_canvas.update()

    def _test_tick(self):
        self.test_tick += 1
        try:
            emu = json.loads(self.emu_editor.toPlainText())
            sv = dict(emu.get("state_vars", {}))
            for rule in emu.get("rules", []):
                if rule.get("action") == "set_state" and rule.get("target"):
                    if rule.get("trigger") == "pin_high":
                        val = rule.get("value")
                        if isinstance(val, bool):
                            sv[rule["target"]] = val if self.test_tick % 2 == 0 else (not val)
                        else:
                            sv[rule["target"]] = val if self.test_tick % 2 == 0 else 0
            self.test_state = sv
            parts = "  |  ".join(f"{k}: {v}" for k, v in sv.items())
            self.state_display.setText(parts or "Empty")
        except Exception:
            pass
        self.test_lbl.setText(f"tick {self.test_tick}")
        self.canvas.update()
        self.preview_canvas.update()

    # ── EXPORT TAB ──
    def _build_export_tab(self):
        w = QWidget()
        layout = QHBoxLayout(w)
        layout.setContentsMargins(0, 0, 0, 0)
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(28, 24, 28, 24)
        ll.setSpacing(10)
        hdr = QLabel("Export Device File")
        hdr.setFont(QFont(T.UI, 18, QFont.Bold))
        ll.addWidget(hdr)
        self.export_summary = QTextEdit()
        self.export_summary.setReadOnly(True)
        self.export_summary.setMaximumHeight(220)
        self.export_summary.setFont(QFont(T.MONO, 11))
        self.export_summary.setStyleSheet(
            "background:" + T.bg + ";border:1px solid " + T.border + ";border-radius:4px;padding:12px"
        )
        ll.addWidget(self.export_summary)
        self.export_err = QLabel("")
        self.export_err.setFont(QFont(T.MONO, 10))
        self.export_err.setStyleSheet("color:" + T.red)
        ll.addWidget(self.export_err)
        btn = QPushButton("Save .adev file")
        btn.setStyleSheet(
            "QPushButton{background:" + T.blue + ";color:#000;border:none;border-radius:4px;"
            "padding:14px;font-size:14px;font-weight:bold}QPushButton:hover{background:#5cb0ff}"
        )
        btn.clicked.connect(self._export)
        ll.addWidget(btn)
        ll.addStretch()
        layout.addWidget(left, 1)

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(0)
        rl.addWidget(_lbl("  JSON Preview"))
        self.export_preview = QPlainTextEdit()
        self.export_preview.setReadOnly(True)
        self.export_preview.setFont(QFont(T.MONO, 11))
        rl.addWidget(self.export_preview)
        layout.addWidget(right, 1)
        self.tabs.addTab(w, "Export")
        self.tabs.currentChanged.connect(self._on_tab_change)

    def _on_tab_change(self, idx):
        name = self.tabs.tabText(idx)
        if name == "Export":
            self._update_export_preview()
        elif name == "Emulation":
            self.emu_pin_list.clear()
            for pin in self.pins:
                self.emu_pin_list.addItem(f'{pin["id"]} ({pin["type"]})')
        elif name == "Preview":
            self.preview_canvas.image = self.canvas.image
            self.preview_canvas.image_path = self.canvas.image_path
            self.preview_canvas.center_view()
        elif name == "Visual":
            self.canvas.update()

    def _update_export_preview(self):
        adev = self._build_adev()
        if adev:
            preview = json.loads(json.dumps(adev))
            img = preview.get("visual", {}).get("image_svg")
            if img and len(img) > 200:
                preview["visual"]["image_svg"] = "(image data truncated)"
            self.export_preview.setPlainText(json.dumps(preview, indent=2))
            self.export_summary.setPlainText(
                f'Name: {adev["device"]["name"]}\n'
                f'ID: {adev["device"]["id"]}\n'
                f'Category: {adev["device"]["category"]}\n'
                f'Size: {adev["visual"]["width"]}x{adev["visual"]["height"]}\n'
                f'Pins: {len(adev.get("pins", []))}\n'
                f'LEDs: {len(adev["visual"].get("led_indicators", []))}\n'
                f'Display: {"Yes" if "display" in adev else "No"}\n'
                f'Image: {"Embedded" if self.image_b64 else "None"}'
            )
            self.export_err.setText("")
        else:
            self.export_err.setText("Fix emulation JSON errors first.")

    # ─────────────────────────────────────────────────────────
    # ACTIONS
    # ─────────────────────────────────────────────────────────
    def _set_vtool(self, t):
        self.canvas.tool = t
        self._sync_tool_btns()

    def _sync_tool_btns(self):
        for k, b in self.vtool_btns.items():
            b.setChecked(k == self.canvas.tool)

    def _toggle_grid(self):
        self.canvas.grid_snap = self.grid_btn.isChecked()
        self._update_grid_btn()
        self.canvas.update()

    def _update_grid_btn(self):
        self.grid_btn.setChecked(self.canvas.grid_snap)
        self.grid_btn.setText("Grid: ON" if self.canvas.grid_snap else "Grid: OFF")

    def _on_opacity(self, val):
        self.canvas.img_opacity = val / 100.0
        self.canvas.update()

    def _fit_image(self):
        if self.canvas.image and not self.canvas.image.isNull():
            self.dev_w.setValue(self.canvas.image.width())
            self.dev_h.setValue(self.canvas.image.height())

    def _upload_image(self):
        f, _ = QFileDialog.getOpenFileName(
            self, "Upload Device Image", "",
            "Images (*.png *.jpg *.jpeg *.bmp);;All (*)",
        )
        if not f:
            return
        img = QImage(f)
        if img.isNull():
            QMessageBox.warning(self, "Error", "Failed to load image.")
            return
        self.canvas.set_image(img, f)
        self.dev_w.setValue(img.width())
        self.dev_h.setValue(img.height())
        with open(f, "rb") as fh:
            self.image_b64 = base64.b64encode(fh.read()).decode("ascii")
        self.preview_canvas.image = img
        self.preview_canvas.image_path = f
        self.st_msg.setText(f"Image: {Path(f).name} ({img.width()}x{img.height()})")
        self._refresh_info()
        self.canvas.center_view()

    def _remove_image(self):
        self.canvas.clear_image()
        self.preview_canvas.image = None
        self.image_b64 = None
        self.st_msg.setText("Image removed")

    def _on_pin_placed(self, x, y):
        idx = len(self.pins)
        self.pins.append({
            "id": f"pin_{idx}", "label": f"P{idx}", "x": x, "y": y,
            "side": "left", "type": "digital", "direction": "io", "notes": "",
        })
        self._save_undo()
        self._refresh_lists()
        self._on_item_clicked("pin", idx)
        self.canvas.update()

    def _on_led_placed(self, x, y):
        idx = len(self.leds)
        self.leds.append({
            "label": f"LED{idx}", "x": x, "y": y, "radius": 8,
            "color": "#ff3344", "state_var": "led_on", "on_value": True,
        })
        self._save_undo()
        self._refresh_lists()
        self._on_item_clicked("led", idx)
        self.canvas.update()

    def _on_display_drawn(self, x, y, w, h):
        self.disp_region = {"x": x, "y": y, "w": w, "h": h}
        self.has_display.setChecked(True)
        self.canvas.update()

    def _on_item_moved(self, typ, idx, x, y):
        """Called after a drag-drop move finishes."""
        self._save_undo()
        # Update editor if this item is selected
        if typ == "pin" and self.sel_type == "pin" and self.sel_idx == idx:
            self.pe_x.blockSignals(True)
            self.pe_y.blockSignals(True)
            self.pe_x.setValue(x)
            self.pe_y.setValue(y)
            self.pe_x.blockSignals(False)
            self.pe_y.blockSignals(False)
        elif typ == "led" and self.sel_type == "led" and self.sel_idx == idx:
            self.le_x.blockSignals(True)
            self.le_y.blockSignals(True)
            self.le_x.setValue(x)
            self.le_y.setValue(y)
            self.le_x.blockSignals(False)
            self.le_y.blockSignals(False)
        self._refresh_lists()

    def _on_mouse_at(self, x, y):
        self.st_coord.setText(f"({x}, {y})")

    def _on_item_clicked(self, typ, idx):
        self.sel_type = typ
        self.sel_idx = idx

        if typ == "pin" and 0 <= idx < len(self.pins):
            pin = self.pins[idx]
            for w in [self.pe_id, self.pe_label, self.pe_notes, self.pe_x, self.pe_y,
                      self.pe_type, self.pe_dir, self.pe_side]:
                w.blockSignals(True)
            self.pe_id.setText(pin["id"])
            self.pe_label.setText(pin["label"])
            self.pe_x.setValue(pin["x"])
            self.pe_y.setValue(pin["y"])
            self.pe_type.setCurrentText(pin["type"])
            self.pe_dir.setCurrentText(pin["direction"])
            self.pe_side.setCurrentText(pin["side"])
            self.pe_notes.setText(pin.get("notes", ""))
            for w in [self.pe_id, self.pe_label, self.pe_notes, self.pe_x, self.pe_y,
                      self.pe_type, self.pe_dir, self.pe_side]:
                w.blockSignals(False)
            self.prop_stack.setCurrentIndex(1)
        elif typ == "led" and 0 <= idx < len(self.leds):
            led = self.leds[idx]
            for w in [self.le_label, self.le_x, self.le_y, self.le_radius,
                      self.le_color, self.le_state_var, self.le_on_value]:
                w.blockSignals(True)
            self.le_label.setText(led["label"])
            self.le_x.setValue(led["x"])
            self.le_y.setValue(led["y"])
            self.le_radius.setValue(led.get("radius", 8))
            self.le_color.setText(led.get("color", "#ff3344"))
            self.le_color_btn.setStyleSheet(
                "background:" + led.get("color", "#ff3344")
                + ";border:1px solid " + T.border + ";border-radius:4px"
            )
            self.le_state_var.setText(led.get("state_var", ""))
            ov = led.get("on_value", True)
            self.le_on_value.setText(str(ov).lower() if isinstance(ov, bool) else str(ov))
            for w in [self.le_label, self.le_x, self.le_y, self.le_radius,
                      self.le_color, self.le_state_var, self.le_on_value]:
                w.blockSignals(False)
            self.prop_stack.setCurrentIndex(2)
        else:
            self._deselect()

        self.canvas.update()
        self.preview_canvas.update()

    def _deselect(self):
        self.sel_type = "none"
        self.sel_idx = -1
        self.prop_stack.setCurrentIndex(0)
        self.pin_list.clearSelection()
        self.led_list.clearSelection()
        self.canvas.update()

    def _upd_pin(self, field, val):
        if self.sel_type == "pin" and 0 <= self.sel_idx < len(self.pins):
            self.pins[self.sel_idx][field] = val
            self._refresh_lists()
            self.canvas.update()

    def _upd_led(self, field, val):
        if self.sel_type == "led" and 0 <= self.sel_idx < len(self.leds):
            if field == "on_value_str":
                if val.lower() == "true":
                    val = True
                elif val.lower() == "false":
                    val = False
                else:
                    try:
                        val = float(val) if "." in val else int(val)
                    except ValueError:
                        pass
                self.leds[self.sel_idx]["on_value"] = val
            else:
                self.leds[self.sel_idx][field] = val
            self._refresh_lists()
            self.canvas.update()

    def _delete_selected(self):
        self._delete_item(self.sel_type, self.sel_idx)

    def _delete_item(self, typ, idx):
        if typ == "pin" and 0 <= idx < len(self.pins):
            self.pins.pop(idx)
        elif typ == "led" and 0 <= idx < len(self.leds):
            self.leds.pop(idx)
        else:
            return
        self._save_undo()
        self._deselect()
        self._refresh_lists()
        self.canvas.update()

    def _duplicate_item(self, typ, idx):
        if typ == "pin" and 0 <= idx < len(self.pins):
            new = copy.deepcopy(self.pins[idx])
            new["x"] += 16
            new["y"] += 16
            new["id"] = f"pin_{len(self.pins)}"
            new["label"] = f"P{len(self.pins)}"
            self.pins.append(new)
            self._save_undo()
            self._refresh_lists()
            self._on_item_clicked("pin", len(self.pins) - 1)
        elif typ == "led" and 0 <= idx < len(self.leds):
            new = copy.deepcopy(self.leds[idx])
            new["x"] += 16
            new["y"] += 16
            new["label"] = f"LED{len(self.leds)}"
            self.leds.append(new)
            self._save_undo()
            self._refresh_lists()
            self._on_item_clicked("led", len(self.leds) - 1)
        self.canvas.update()

    def _auto_layout_pins(self, side):
        """Distribute all pins evenly along an edge."""
        if not self.pins:
            return
        dw = self.dev_w.value()
        dh = self.dev_h.value()
        n = len(self.pins)
        for i, pin in enumerate(self.pins):
            pin["side"] = side
            if side == "left":
                pin["x"] = 0
                pin["y"] = int(dh * (i + 1) / (n + 1))
            elif side == "right":
                pin["x"] = dw
                pin["y"] = int(dh * (i + 1) / (n + 1))
            elif side == "top":
                pin["x"] = int(dw * (i + 1) / (n + 1))
                pin["y"] = 0
            elif side == "bottom":
                pin["x"] = int(dw * (i + 1) / (n + 1))
                pin["y"] = dh
        self._save_undo()
        self._refresh_lists()
        self.canvas.update()
        self.st_msg.setText(f"Pins distributed along {side} edge")

    def _pick_led_color(self):
        c = QColorDialog.getColor(QColor(self.le_color.text()), self)
        if c.isValid():
            self.le_color.setText(c.name())

    def _refresh_lists(self):
        self.pin_list.clear()
        for pin in self.pins:
            self.pin_list.addItem(
                f'{pin["label"]}  ({pin["type"]})  @{pin["x"]},{pin["y"]}'
            )
        self.led_list.clear()
        for led in self.leds:
            self.led_list.addItem(
                f'{led["label"]}  -> {led.get("state_var", "?")}'
            )
        self._refresh_info()

    def _refresh_info(self):
        if hasattr(self, "vis_info"):
            self.vis_info.setText(
                f"{self.dev_w.value()}x{self.dev_h.value()} | "
                f"{len(self.pins)} pins | {len(self.leds)} LEDs"
            )

    # ── BUILD .adev ──
    def _build_adev(self):
        if not self._validate_emu():
            return None
        try:
            emu = json.loads(self.emu_editor.toPlainText())
        except Exception:
            return None

        adev = {
            "format_version": "1.0",
            "device": {
                "id": self.dev_id.text(), "name": self.dev_name.text(),
                "category": self.dev_category.currentText(),
                "description": self.dev_desc.toPlainText(),
                "author": self.dev_author.text(), "version": self.dev_version.text(),
            },
            "visual": {
                "width": self.dev_w.value(), "height": self.dev_h.value(),
                "label": self.dev_label.text(), "color": self.dev_color.text(),
            },
            "pins": [dict(p) for p in self.pins],
            "emulation": emu,
        }
        if self.image_b64:
            ext = Path(self.canvas.image_path or "x.png").suffix.lower()
            mime = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg"}.get(ext, "image/png")
            ww, hh = self.dev_w.value(), self.dev_h.value()
            adev["visual"]["image_svg"] = (
                f"<svg xmlns='http://www.w3.org/2000/svg' width='{ww}' height='{hh}'>"
                f"<image href='data:{mime};base64,{self.image_b64}' width='{ww}' height='{hh}'/></svg>"
            )
        if self.leds:
            adev["visual"]["led_indicators"] = [
                {"label": l["label"], "x": l["x"], "y": l["y"],
                 "radius": l.get("radius", 8), "color": l.get("color", "#ff3344"),
                 "state_var": l.get("state_var", ""), "on_value": l.get("on_value", True)}
                for l in self.leds
            ]
        if self.has_display.isChecked():
            adev["display"] = {
                "type": self.disp_type.text(), "width_px": self.disp_px_w.value(),
                "height_px": self.disp_px_h.value(), "pixel_color": self.disp_color.text(),
                "background_color": self.disp_bg.text(), "region": dict(self.disp_region),
                "interface": self.disp_iface.currentText(), "address": self.disp_addr.text(),
            }
        return adev

    # ── EXPORT / IMPORT ──
    def _export(self):
        adev = self._build_adev()
        if not adev:
            QMessageBox.warning(self, "Error", "Fix emulation JSON errors first.")
            return
        name = self.dev_id.text() or "device"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Device File", f"{name}.adev",
            "Device Files (*.adev);;JSON (*.json);;All (*)",
        )
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            json.dump(adev, f, indent=2)
        self.st_msg.setText(f"Exported: {Path(path).name}")
        QMessageBox.information(self, "Done", f"Saved to:\n{path}")

    def _import_adev(self):
        f, _ = QFileDialog.getOpenFileName(
            self, "Import Device File", "",
            "Device Files (*.adev *.json);;All (*)",
        )
        if not f:
            return
        try:
            with open(f, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
            return

        dev = data.get("device", {})
        vis = data.get("visual", {})
        self.dev_id.setText(dev.get("id", ""))
        self.dev_name.setText(dev.get("name", ""))
        cat_idx = self.dev_category.findText(dev.get("category", "Other"))
        if cat_idx >= 0:
            self.dev_category.setCurrentIndex(cat_idx)
        self.dev_desc.setPlainText(dev.get("description", ""))
        self.dev_author.setText(dev.get("author", ""))
        self.dev_version.setText(dev.get("version", "1.0"))
        self.dev_w.setValue(vis.get("width", 100))
        self.dev_h.setValue(vis.get("height", 100))
        self.dev_label.setText(vis.get("label", ""))
        self.dev_color.setText(vis.get("color", "#555"))
        self.pins = list(data.get("pins", []))
        self.leds = list(vis.get("led_indicators", []))
        if data.get("emulation"):
            self.emu_editor.setPlainText(json.dumps(data["emulation"], indent=2))
        if data.get("display"):
            self.has_display.setChecked(True)
            d = data["display"]
            self.disp_type.setText(d.get("type", ""))
            self.disp_px_w.setValue(d.get("width_px", 128))
            self.disp_px_h.setValue(d.get("height_px", 64))
            self.disp_color.setText(d.get("pixel_color", "#00aaff"))
            self.disp_bg.setText(d.get("background_color", "#000510"))
            if "region" in d:
                self.disp_region = d["region"]
            ii = self.disp_iface.findText(d.get("interface", "i2c"))
            if ii >= 0:
                self.disp_iface.setCurrentIndex(ii)
            self.disp_addr.setText(d.get("address", "0x3C"))
        self._save_undo()
        self._refresh_lists()
        self.canvas.update()
        self.canvas.center_view()
        self.st_msg.setText(f"Imported: {Path(f).name}")

    # ── Keyboard shortcuts ──
    def keyPressEvent(self, e):
        if e.modifiers() == Qt.ControlModifier:
            if e.key() == Qt.Key_Z:
                self._do_undo()
                return
            elif e.key() == Qt.Key_S:
                self._export()
                return
            elif e.key() == Qt.Key_D:
                self._duplicate_item(self.sel_type, self.sel_idx)
                return
        if e.modifiers() == (Qt.ControlModifier | Qt.ShiftModifier):
            if e.key() == Qt.Key_Z:
                self._do_redo()
                return
        super().keyPressEvent(e)


# ═══════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════
def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    pal = QPalette()
    pal.setColor(QPalette.Window, QColor(T.bg))
    pal.setColor(QPalette.WindowText, QColor(T.text))
    pal.setColor(QPalette.Base, QColor(T.panel))
    pal.setColor(QPalette.Text, QColor(T.text))
    pal.setColor(QPalette.Button, QColor(T.panel))
    pal.setColor(QPalette.ButtonText, QColor(T.text))
    pal.setColor(QPalette.Highlight, QColor(T.blue))
    pal.setColor(QPalette.HighlightedText, QColor("#000"))
    app.setPalette(pal)
    win = DeviceCreator()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
