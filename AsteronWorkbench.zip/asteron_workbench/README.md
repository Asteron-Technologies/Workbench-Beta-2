# Asteron Workbench
**By Asteron Technologies**

## Quick Start (Windows)
1. `Install_Dependencies.bat` (one-time)
2. `Workbench_IDE.bat` — circuit simulator
3. `Workbench_DeviceCreator.bat` — device file builder

## Device Creator — New Features
- **Drag pins & LEDs** directly on canvas to reposition
- **Canvas pan** (middle-click or Space+drag) & **zoom** (scroll wheel)
- **Grid snap** with toggle (G key), 8px grid with visual guides
- **Image opacity** slider for tracing over reference images
- **Fit Image** button to auto-size canvas to image dimensions
- **Right-click context menus** on pins, LEDs, and empty canvas
- **Undo/Redo** (Ctrl+Z / Ctrl+Shift+Z)
- **Duplicate** items (Ctrl+D or right-click)
- **Auto-layout** pins along any edge (L/R/T/B buttons)
- **Selection highlighting** with dashed orange border
- **Crosshair guides** when placing pins/LEDs
- **Mouse coordinates** in status bar
- Keyboard shortcuts: Del, Ctrl+S, Ctrl+D, Escape
