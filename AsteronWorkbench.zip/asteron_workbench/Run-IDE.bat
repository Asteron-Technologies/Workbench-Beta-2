@echo off
title Asteron Workbench - IDE
cd /d "%~dp0"
python workbench_ide.py
if errorlevel 1 (echo. & echo ERROR: pip install PyQt5 & pause)
